#include <iostream>
#include <set>
#include <string>
#include <vector>
#include <algorithm>
using namespace std;

bool ordena (const string& a, const string& b){
	if (a.size()==b.size()) return a<b;
	return a.size() < b.size();
}

void game (set <string>& S, set <string>& had, int games){
	if (games>1) cout<<endl;
	cout<<"GAME #"<< games << endl;
	cout<< "HAS:" << endl;
	for (auto it = S.begin(); it!=S.end(); ++it){
		cout<< *it<<endl;
	}
	cout<< endl;

	cout<< "HAD:" << endl;
	vector<string> v;
	for (auto it = had.begin(); it!=had.end(); ++it){
		v.push_back(*it);
	}
	sort(v.begin(), v.end(), ordena);
	for (int i =0; i<v.size(); ++i){
		cout<< v[i]<<endl;
	}
}

int main(){
	set <string> S;
	set <string> had;
	set <string> buit;

	string w;
	int games=1;
	while (cin>>w){
		if (w=="QUIT"){
			game(S,had,games);
			return 0;
		}
		if (w=="END"){
			game(S,had,games);
			S=buit;
			had=buit;
			++games;
		}
		else {
			if (S.count(w)>0){
				S.erase(w);
				had.insert(w);
			}
			else {
				had.erase(w);
				S.insert(w);
			}
		}

	}
}