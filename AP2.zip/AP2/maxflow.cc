#include <iostream>
#include <vector>
#include <queue>
#include <stack>
#include <map>
#include <cmath>
using namespace std;
//Maxflow
struct Aresta{
	int dest;
	int weight;
};

using Graph = vector<vector<Aresta>>;
using Flow = vector<map<int,int>>;

int aresta_minima (Flow& F, const vector<int>& pre,int vertexs){

	int minim = 1000000000;
	for (int u = vertexs-1; u!=0; u=pre[u]){
		minim = min(minim, F[pre[u]][u]);

	}

	return minim;
}

void canvia_arestes (Flow& F, const vector<int>& pre, int vertexs, int min){
	for (int u = vertexs-1; u!=0; u=pre[u]){
		F[pre[u]][u] -= min;
		F[u][pre[u]] += min;
	}
}

bool there_is_a_path (Graph& G, Flow& F, int vertexs, vector<int>& pre){
	//BFS
	vector<bool> visited (vertexs,false);

	queue <Aresta> Q;
	Q.push({0,0});

	visited[0]=true;
	while (!Q.empty()){
		int u = Q.front().dest;
		Q.pop();
		for (Aresta v : G[u]){
			if (not visited[v.dest] and F[u][v.dest]!=0){
				Q.push(v);
				pre[v.dest]=u; //pre[v.dest].weight=F[u][v.dest];
				visited[v.dest]=true;
				if (v.dest == vertexs-1) return true;
			}
		}
		
	}
	return false;

}

void Ford_Fulkerson (Graph& G, Flow& F, int vertexs){
	vector <int> pre(vertexs);
	pre[0]=0; //pre[0].weight=0;
	int maxflow = 0;

	while (there_is_a_path(G,F,vertexs,pre)){
		int min = aresta_minima(F,pre,vertexs);
		maxflow += min;
		canvia_arestes (F,pre,vertexs,min);
	}

	cout << maxflow << endl;
}


int main(){
	int vertexs, arestes;
	while (cin >> vertexs >> arestes){
		int u, v, c;
		Graph G(vertexs);
		Flow F (vertexs);
		for (int i = 0; i< arestes; ++i){
			cin >> u >> v >> c;
			G[u].push_back({v,c});
			G[v].push_back({u,c});
			F[u][v]=c;
		}
		Ford_Fulkerson(G,F,vertexs);

	}
}