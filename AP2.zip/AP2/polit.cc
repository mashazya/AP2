#include <iostream>
#include <map>
#include <string>
#include <set>
#include <vector>
#include <algorithm>
using namespace std;

void calcula_espais(vector<int>& espais, map <string, int> politicians, int linees){
	int posicio = 0;
	int max = 0;
	while(politicians.size()>0){
			auto it = politicians.begin();
			for(int i = 0; i<linees and it!=politicians.end(); ++i){
				//cout << "lletres en " << it->first << ": "<< it->first.size()<<endl;
				//cout << "numeros:" << to_string(it->second).size()<<endl;

				int k = it->first.size()+to_string(it->second).size();
				//cout << "k=:" << k <<endl;

				if(k > max) max = k;
				++it;
			}

			++max;
			//cout << "MAXIM = " << max <<endl;

			it = politicians.begin();
			for(int i = 0; i<linees and politicians.size()>0; ++i){
				it = politicians.begin();
				int caracters = it->first.size()+to_string(it->second).size();
				//cout << "AFEGEIXO ESPAIS: " << max - caracters <<endl;
				espais[posicio]= max - caracters;
				++posicio;
				politicians.erase(it->first);
				//cout << "polit size " << politicians.size() <<endl;

			}
			max = 0;
	}

}

void escriu_files (map <string, int>& politicians, vector<string>& v, int linees){
	int quants_sobren = politicians.size()%linees;
	int quants_per_linea = politicians.size()/linees;
	int contador_linees = quants_per_linea;
	int pocisio_inicial = 0;
	vector <int> espais (v.size());
	calcula_espais (espais, politicians, linees);

	while(politicians.size() > 0){
		int pocisio = pocisio_inicial;
		quants_per_linea = contador_linees;
		if (quants_sobren > 0) {
			++quants_per_linea;
			--quants_sobren;
		}
		for (int i = quants_per_linea; i>0; --i){
			auto it = politicians.find(v[pocisio]);
			// output
			//cout<< "ESCRIC ESPAIS: " << espais[iterador]<<endl;
			cout << it->first;
			for (int i = 0; i< espais[pocisio]; ++i){
				cout << " ";
			}

			cout<< it-> second;
			if (i>1) cout << " | ";


			politicians.erase(v[pocisio]);
			if(quants_per_linea>1 and pocisio + linees < v.size()) pocisio += linees;
			else ++pocisio;
		}
		cout<<endl;
		++pocisio_inicial;

	}

	cout << "****************************************" <<endl;

}

void crea_vector (map <string, int>& politicians, vector<string>& names){
	for (auto it = politicians.begin(); it != politicians.end(); ++it){
		names.push_back(it->first);
	}
}

int main(){
	int columnes;
	while (cin >> columnes){
		string action;
		map <string, int> politicians;
		vector <string> names;
		while (cin >> action and action != "END"){
			if (action == "R"){
				string name;
				int money;
				cin >> name >> money;
				politicians[name] += money;

			}
			else if (action == "G"){
				string name;
				int money;
				cin >> name >> money;
				if (politicians.count(name)==1) politicians[name] -= money;
				else politicians.insert({name, money*(-1)});

			}
			else {
				string name1, name2;
				int money;
				cin >> name1 >> money >> name2;
				if (politicians.count(name1)==1) politicians[name1] -= money;
				else politicians.insert({name1, -money});
				politicians[name2] += money;

			}
		}
		crea_vector(politicians,names);
		escriu_files(politicians, names, columnes);
	}
}