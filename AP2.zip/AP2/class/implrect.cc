#include <iostream>
#include "Rectangle.hh"
#include "Point.hh"
using namespace std;

int main(){

	Point ll (3.0 , 3.0);
	Point ur (6.0,5.0);
	Rectangle R (ll, ur);

MIRAR FUNCIONS PER SEPARAT!!!!!!! 

//is point inside
	Point p (7.0, 3.0);
	if (R.isPointInside(p)) cout<<"inside"<<endl;
	else cout<<"not inside"<<endl;


//flip
	Point ll (3.0 , 3.0);
	Point ur (6.0,5.0);
	Rectangle R (ll, ur);
	R.flip(0);
	cout<< "flip vert: (expected result ll=(3,5) ur=(6,7)" << endl;
		Point llR = R.getLL();
		Point urR = R.getUR();
	cout<< "ll=("<< llR.getX() << ","<<llR.getY()<<")"<<endl;
	cout<< "ur=("<< urR.getX() << ","<<urR.getY()<<")"<<endl;


//rotate
	Point ll (2.0 , 2.0);
	Point ur (7.0,5.0);
	Rectangle R (ll, ur);
	R.rotate(1);
	cout<< "rotate clockwise: (expected result ll=(7,2) ur=(10,7)" << endl;
		Point llR = R.getLL();
		Point urR = R.getUR();
	cout<< "ll=("<< llR.getX() << ","<<llR.getY()<<")"<<endl;
	cout<< "ur=("<< urR.getX() << ","<<urR.getY()<<")"<<endl;

}
