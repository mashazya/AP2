#include "Point.hh"
#ifndef __RECTANGLE_H__
#define __RECTANGLE_H__

class Rectangle{
public:
	//constructor
	Rectangle (Point ll, Point ur);

	//retorna width
	double getW() const;

	//retorna height
	double getH() const;

	//retorna ll
	Point getLL() const;

	//retorna ur
	Point getUR() const;

	//rotacio 90 
	void rotate(bool clockwise);

	//flip hor or vert
	void flip(bool horizontally);

	//if point inside rectangle
	bool isPointInside (const Point& p) const;


private:
	Point ll,ur;
	
};

Rectangle::Rectangle(Point ll, Point ur) :
	ll (ll), ur(ur) {}
double Rectangle::getW() const {
	return (ur.getX()-ll.getX());
}
double Rectangle::getH() const {
	return (ur.getY()-ll.getY());
}
Point Rectangle::getLL() const {
	return ll;
}
Point Rectangle::getUR() const {
	return ur;
}
void Rectangle::rotate(bool clockwise){
	double w = getW();
	double h = getH();
	double llx, lly, urx, ury;//noves coordenades

	if (clockwise){
		llx = ll.getX()+w;
		lly = ll.getY();
		urx = llx + h;
		ury= lly + w;
	}
	else {
		llx = ll.getX()-h;
		lly = ll.getY();
		urx = llx + h;
		ury = lly + w;

	}
	
	Point llR(llx, lly);
	Point urR(urx, ury);
	Rectangle R (llR, urR);
	*this = R;

}
void Rectangle::flip(bool horizontally){
	double w = getW();
	double h = getH();
	double llx, lly, urx, ury;//noves coordenades
	if (horizontally){
		llx = ll.getX()-w;
		lly = ll.getY();
		urx = ur.getX()-w;
		ury = ur.getY();
	}
	else{
		llx = ur.getX()-w;
		lly = ur.getY();
		urx = ur.getX();
		ury = ur.getY()+h;
	}
	Point llR (llx, lly);
	Point urR (urx, ury);
	Rectangle R (llR, urR);
	*this = R;

}
bool Rectangle::isPointInside(const Point& p) const{
	if ((p.getX() >= ll.getX()) and (p.getX() <= ur.getX()) and (p.getY() >= ll.getY()) and (p.getY() <= ur.getY())){
		return true;
	}
	return false;
}

#endif // __RECTANGLE_H__








