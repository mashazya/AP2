#ifndef __POINT_H__
#define __POINT_H__

class Point {
public:
	// Constructor
	Point(double x_coord, double y_coord);
	  // Gets the x coordinate
	double getX() const;
	// Gets the y coordinate
	double getY() const;

private:
	double x, y;  // Coordinates of the point
};

Point::Point(double x_coord, double y_coord) {
  x = x_coord; y = y_coord;
}
double Point::getX() const {
    return x;
}
  double Point::getY() const {
    return y;
}
#endif // __POINT_H__