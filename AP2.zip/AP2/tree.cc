#include <iostream>
#include <vector>
#include <stack>
#include <stdio.h> 
using namespace std;

struct BinTree{
	int vertex;
	BinTree* left;
	BinTree* right;
};


using Tree = BinTree*;

Tree read_tree (){
	Tree T;
	int v;
	if(cin >> v and v != -1){
		Tree left = read_tree();
		Tree right = read_tree();
		T = new BinTree{v, left, right};
		return T;
	}
	return nullptr;

}

void print(int& i){
	cout << i;
}

void post_order (Tree T){
	if (T != nullptr){
		post_order(T->left);	
		post_order(T->right);
		cout << " ";
		print(T->vertex);
	}
}

void in_order (Tree T){
	if (T != nullptr){
		in_order(T->left);
		cout << " ";
		print(T->vertex);	
		in_order(T->right);
	}
}

int main (){
	Tree T = read_tree();
	cout << "pos:";
	post_order(T);
	cout << endl;
	cout << "ino:";
	in_order(T);
	cout << endl;

}