#include <iostream>
#include <vector>
#include <map>
using namespace std;

void even (int& n, int x){

	n = n/2 + x;
}

void odd (int& n, int y){

	n = 3*n + y;
}

void que_paso(int n, map<int,int>& c,int contador){
	if (n > 100000000) cout << n << endl;
	else {
		cout<< contador - c[n]<< endl;
	}
}

int main(){
	int x, y, n;
	while (cin >> x >> y >> n){
		map <int,int> c;
		int contador = 0;
		while (n <= 100000000 and c.find(n)==c.end()){
			c[n] = contador;
			++contador;
			if (n%2 == 0) even(n,x);
			else odd(n,y);
		}

		que_paso(n,c,contador);
	}
}