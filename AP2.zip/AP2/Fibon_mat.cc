#include <iostream>
#include <vector>
using namespace std;
using Matrix = vector<vector<int>>;

Matrix exponent (Matrix M, int n, int m, Matrix u){
	if (n==0) return u;
	if (n%2==0){
		Matrix x = exponent(M, n/2, m,u);
		Matrix res(2,vector<int>(2));

		for (int i = 0; i<M.size(); ++i){
			for (int j = 0; j<M.size(); ++j){
				int suma=0;
				for (int k = 0; k<M.size(); ++k){
					suma=suma+(x[i][k]*x[k][j]);
				}
				res[i][j]=suma%m;
			}
		}
		return res;
	}
	else{
		Matrix x = exponent(M,n-1,m,u);
		Matrix res(2,vector<int>(2));
		for (int i = 0; i<M.size(); ++i){
			for (int j = 0; j<M.size(); ++j){
				int suma=0;
				for (int k = 0; k<M.size(); ++k){
					suma=suma+(M[i][k]*x[k][j]);
				}
				res[i][j]=suma%m;
			}
		}
		return res;
	}
	return M;
}

void resultat (Matrix M, int n, int m, Matrix u){
	Matrix x = exponent(M,n,m,u);
	cout<< x[0][1] << endl;
}

int main(){
	int n,m;
	Matrix M (2,vector<int>(2));
	while(cin>>n>>m){
		Matrix M (2,vector<int>(2));
		M[0][0]=1; M[0][1]=1;
		M[1][0]=1; M[1][1]=0;

		Matrix u (2,vector<int>(2));
		u[0][0]=1;u[0][1]=0;
		u[1][0]=0;u[1][1]=1;
		resultat(M,n,m,u);
	}
}