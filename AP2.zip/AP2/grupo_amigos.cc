#include <iostream>
#include <vector>
#include <queue>
#include <string>
#include <algorithm>
#include <set>
#include <map>
using namespace std;
using Graph = map<string,set<string>>;

set<string> operator+(const set<string>& s1, const set<string>& s2) {
    set<string> s = s1;
    s.insert(s2.begin(), s2.end());
    return s;
}
/*bool find_names (Graph& G, int& set, vector<string> names){
	
	for (int j = 0; j<names.size(); ++j){
		for (int i = 0; i<G.size(); ++i){
			auto it = G[i].find(names[j]);
			if ( it != G[i].end()){
				set = i;
				return true;
			}
		}
	}
	return false;
}*/

void opera_F(Graph& G){
	int n;
	string name;
	cin >> n;
	set <string> amigos;
	for (int i = 0; i<n; ++i){
		cin >> name;
		amigos.insert(name);
		
	}
	for (auto it = amigos.begin(); it != amigos.end(); ++it){
		
		G[*it] = G[*it] + amigos; 
		Graph copia = G;
		for (auto e = G[*it].begin(); e != G[*it].end(); ++e){
			cout << *e << endl;
			copia[*e] = copia[*e] + amigos; 
		}
		G = copia;

	}
	
}
void opera_Q(Graph& G){
	string name;
	cin >> name;
	cout << name << ": ";
	if (G.count(name)==0) cout << "error" <<endl;
	else cout << G[name].size() <<endl;
}

int main(){
	char c;
	Graph G;
	while (cin >> c){
		if (c == 'F'){
			opera_F(G);
		}
		else if (c == 'Q'){
			opera_Q(G);
		}
	}
}



/*cin >> name;
		names.push_back(name);
		int posicio;
		if (G.size() == 0 or not find_names(G,posicio, names)){
			set<string> amigo = {name};
			G.push_back(amigo);
		}
		else{
			G[posicio].insert(name);
		}*/


