#include <iostream>
#include <vector>
#include <map>
#include <cmath>
#include <queue>
using namespace std;

using Graph = vector<vector<int>>;
using Flow = vector<map<int,int>>;

/*int calcula_minim(Graph& G, Flow& F,vector<int>& path, int vertexs){
	int source = vertexs;
	int dest = vertexs+1;
	int minim = 1000000000;
	for (int i = dest; i!= source; i=path[i]){
		minim = min(minim, F[path[i]][i]);
	}
	return minim;
}*/

void canvia_arestes(Flow& F,vector<int>& path, int vertexs){
	//cout<< "stoi aqui"<<endl;
	int source = vertexs;
	int dest = vertexs+1;
	for (int u = dest; u!=source; u=path[u]){
		F[path[u]][u]-= 1;
		//cout << "F[path[u]][u] = " << F[path[u]][u] <<endl;
		F[u][path[u]]+= 1;
		//cout << "F[u][path[u]] = " << F[u][path[u]] <<endl;

	}
}

bool check_color (Graph& G, int v, vector<int>& color){
	color[v] = 1;
	queue <int> Q;
	Q.push(v);

	while (!Q.empty()){
		int v = Q.front();
		Q.pop();
		for (int u : G[v]){
			if(color[u] < color[v]){
				color[u]= 1 - color[v];
				Q.push(u);
			}
			else if (color[u]==color[v])return false;
		}
	}
	return true;
}


bool bipartit (Graph& G, int vertexs){
	
	vector<int> color(vertexs,-1);
	for (int i = 0; i<vertexs; ++i){
		if (color[i] == -1){
			if (!check_color(G,i,color)) return false;
		}
	}
	return true;
}

int main(){
	int vertexs, arestes;
	while (cin >> vertexs >> arestes){
		int x,y;
		
		Graph G (vertexs);
		
		for (int i=0; i<arestes; ++i){
			cin >> x >> y;
			G[x].push_back(y);
			G[y].push_back(x);
		}
		
		if (bipartit(G,vertexs)) cout << "yes"<< endl;
		else cout << "no"<< endl;
	}
}