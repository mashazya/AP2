#include <iostream>
#include <vector>
#include <set>
using namespace std;
using Graph = vector<vector<int>>;

Graph read_graph (vector <int>& how_many_before, int cond){
	int x,y;
	Graph G (how_many_before.size(), vector<int>(0));
	for (int i = 0; i < cond; ++i){
		cin >> x >> y;
		++how_many_before[y];
		G[x].push_back(y);
	}
	return G;
}

set <int> create_set (const vector <int> & how_many_before){
	int n = how_many_before.size();
	set <int> S;
	for(int i = 0; i<n; ++i){
		if (how_many_before[i]==0){
			S.insert(i);
		}
	}
	return S;
}

void escriu(const Graph & G, vector<int>& how_many_before, set<int>& S){

	while (!S.empty()){
		int u = *S.begin();
		S.erase(u);
		cout << u;
		for (int i : G[u]){
			--how_many_before[i];
			if (how_many_before[i]==0) S.insert(i);
		}
		if (!S.empty()) cout << " ";

	}
	cout << endl;
}


int main (){

	int tasks, cond;
	while(cin >> tasks >> cond){
		vector <int> how_many_before (tasks,0);
		Graph G = read_graph(how_many_before, cond);
		set <int> S = create_set (how_many_before);
		escriu(G,how_many_before,S);
	}


}



