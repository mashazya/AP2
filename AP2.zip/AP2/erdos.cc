#include <iostream>
#include <vector>
#include <queue>
using namespace std;
using Adj = vector<vector<int>>;
int inf = 100000000;

void conta_erdos (Adj& A, int vertexs, vector<int>& erdos){
	vector<bool> visited(vertexs,false);
	erdos[0] = 0;
	queue<int> Q;
	Q.push(0);
	visited[0]=true;
	while(!Q.empty()){
		int u = Q.front(); Q.pop();
		for (int v : A[u]){
			if (!visited[v]){
				erdos[v] = erdos[u]+1;
				visited[v]=true;
				Q.push(v);
			}
		}

	}
}

void escriu_erdos(vector<int> erdos){
	for (int i = 0; i<erdos.size(); ++i){
		cout << i << " : ";
		if (erdos[i]<inf) cout << erdos[i];
		else cout << "no";
		cout << endl;
		
	}
	cout << "----------"<<endl;
}

int main(){
	int n_maths,n_works; //n_maths = n_vertexs
	int n_coauthors, author;
	//cada aresta es una colaboracio
	while(cin >> n_maths >> n_works){
		Adj A(n_maths);
		for (int i = 0; i<n_works; ++i){
			cin >> n_coauthors;
			vector<int> authors(n_coauthors);
			for (int j = 0; j<n_coauthors; ++j){
				cin >> authors[j];
			}
			for (int j = 0; j<n_coauthors; ++j){
				for (int k = 0; k<n_coauthors; ++k){
					A[authors[j]].push_back(authors[k]);
				}
			}
		}
		vector<int> erdos(n_maths, inf);
		conta_erdos(A,n_maths, erdos);
		escriu_erdos(erdos);
	}
	

}