#include <iostream>
#include <vector>
#include <queue>
using namespace std;

//Bellman-Ford

struct Aresta {
	int destiny, cost;
};

bool operator < (const Aresta& a, const Aresta& b){
	return a.cost > b.cost;
}

using Graph = vector<vector<Aresta>>;

void read_arc (Graph& G){
	int source, destiny, cost;
	cin >> source >> destiny >> cost;
	G[source].push_back({destiny, cost});
}

const int inf = 1000000000;

int bellmanford (Graph& G, int x, int y, int vertexs){
	vector <int> dist(vertexs, inf);
	dist[x]=0;

	vector <bool> visitat(vertexs, false);

	for (int i = 0; i < vertexs; ++i){
		for (int vert=0; vert<vertexs; ++vert){
			for (Aresta v : G[vert]){
				if (dist[v.destiny] > dist[vert] + v.cost){
					dist[v.destiny] = dist[vert] + v.cost;
				}
			}
		}
	}
	return dist[y];

}

void escriu_distancia (Graph& G, int vertexs){
	int x,y;
	cin >> x >> y;
	int minima_dist = bellmanford(G, x, y, vertexs);
	if (minima_dist != inf) cout << minima_dist << endl;
	else cout << "no path from " << x << " to " << y << endl;
}

int main(){
	int vertexs, arestes;
	while(cin >> vertexs >> arestes){
		Graph G(vertexs);
		for (int i = 0; i < arestes; ++i){
			read_arc(G);
		}
		escriu_distancia(G,vertexs);
	}
}