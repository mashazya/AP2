#include <iostream>
#include <vector>
#include <stack>
#include <queue> 
using namespace std;

struct Node{
	int dest;
	int cost;
};

using Graph = vector<vector<Node>>;
const int inf = 1000000;


//operador per la cua de prioritats 
bool operator < (const Node& a, const Node& b){
	return a.cost > b.cost;
}


void busca_cami_barat(int A, int B, Graph& G, int vertexs, vector <int> nit){
	//Dijkstra
	vector<bool> visited (vertexs,false);
	vector<int> dist (vertexs,inf); //distancies fins els nodes
	dist[A]=0;// cost del primer vertexs no es te en compte

	priority_queue <Node> Q;
	Q.push({A,0});
	while (!Q.empty()){
		int u = Q.top().dest; Q.pop();
		if (!visited[u]){
			visited[u]=true;
			for (Node v : G[u]){
				int cost_nit = 0;
				if (v.dest != B) cost_nit = nit[v.dest]; // no ha de contar el vertex B
				//modificacio del Dijkstra normal que li afegim no
				//nomes el cost de l'aresta sino tmb el cost del vertexs
				if (dist[v.dest] > dist[u] + v.cost + cost_nit){ 
					dist[v.dest] = dist[u] + v.cost +  cost_nit;
					Q.push({v.dest, dist[v.dest]});
				}
			}
		}

	}

	cout << "c(" << A << "," << B << ") = ";
	if (dist[B]!=inf) cout << dist[B] << endl;
	else cout << "+oo"<<endl;
}

int main(){
	int vertexs,arestes;
	cin >> vertexs >> arestes;
	vector <int> nit (vertexs); //costos dels vertexs

	Graph G(vertexs);
	for (int i = 0; i<vertexs; ++i){
		int cost_nit;
		cin >> cost_nit;
		nit[i]=cost_nit;
	}
	for (int i = 0; i<arestes; ++i){
		int u,v,c;
		cin >> u >>v>>c;
		G[u].push_back({v,c});
		G[v].push_back({u,c});
	}

	int A,B; 
	while (cin >> A >> B){
		busca_cami_barat(A,B,G,vertexs,nit);
	}
}