#include <iostream>
#include <map>
#include <string>
#include <queue>
#include <set>
using namespace std;

int main(){
	string w;
	map <string, string> couples;
	set <string> alone;

	while(cin>>w){
		if (w=="info"){
			cout<< "COUPLES:"<<endl;
			for(auto e: couples){
				if (e.first < e.second){
					cout<< e.first << " " << e.second<<endl;
				}
			}
			cout<< "ALONE:"<<endl;
			for (auto it = alone.begin(); it!= alone.end(); ++it){
				cout<<*it<<endl;
			}
			cout<< "----------"<<endl;

		}
		else if (w=="affair"){
			string x, y;
			cin >> x >> y;
			if (alone.count(x)>0) alone.erase(x);
			if (alone.count(y)>0) alone.erase(y);

			if (couples.find(x)!=couples.end()){
				alone.insert(couples[x]);
				couples.erase(couples[x]);
			}
			if (couples.find(y)!=couples.end()){
				alone.insert(couples[y]);
				couples.erase(couples[y]);
			}
		
			couples[x]=y;
			couples[y]=x;
		}
	}
}