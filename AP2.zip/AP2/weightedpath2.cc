#include <iostream>
#include <vector>
#include <stack>
#include <queue>
using namespace std;

//Dijkstra

struct Aresta {
	int destiny, cost;
};

bool operator < (const Aresta& a, const Aresta& b){
	return a.cost > b.cost;
}

using Graph = vector<vector<Aresta>>;

void read_arc (Graph& G){
	int source, destiny, cost;
	cin >> source >> destiny >> cost;
	G[source].push_back({destiny, cost});
}

const int inf = 1000000000;

void escriu_cami (const Graph& G, const vector<int>& pred, int x, int y){
	stack <int> S;
	int posicio = y;
	S.push(posicio);
	while (pred[posicio]!=posicio){
		S.push(pred[posicio]);
		posicio=pred[posicio];
	}
	while(!S.empty()){
		cout << S.top();
		S.pop();
		if (!S.empty()) cout << " ";
	}
	cout<<endl;
}

void dijkstra (Graph& G, int x, int y, int vertexs){
	vector <int> dist(vertexs, inf);
	dist[x]=0;

	priority_queue <Aresta> Q;
	Q.push({x,0});

	vector <bool> visitat(vertexs, false);
	vector <int> pred (vertexs, inf);
	pred[x] = x;

	while (!Q.empty()){
		int u = Q.top().destiny;
		Q.pop();
		if (!visitat[u]){
			visitat[u] = true;
			for (Aresta v : G[u]){
				if (dist[v.destiny] > dist[u] + v.cost){
					dist[v.destiny] = dist[u] + v.cost;
					pred[v.destiny] = u;
					Q.push({v.destiny, dist[v.destiny]});
				}
			}
		}
	}
	if (dist[y] != inf) escriu_cami(G,pred,x,y);
	else cout << "no path from " << x << " to " << y << endl;
}

void escriu_distancia (Graph& G, int vertexs){
	int x,y;
	cin >> x >> y;
	dijkstra(G, x, y, vertexs);
}

int main(){
	int vertexs, arestes;
	while(cin >> vertexs >> arestes){
		Graph G(vertexs);
		for (int i = 0; i < arestes; ++i){
			read_arc(G);
		}
		escriu_distancia(G,vertexs);
	}
}