#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
using namespace std;
using Adj = vector<vector<int>>;

void colora_graf (Adj& A, int vertexs, int& colors){
	vector<int> coloracio (vertexs,0);
	coloracio[0]=1;
	for (int u = 0; u<vertexs; ++u){
		vector<bool> agafats(vertexs+1,false);
		agafats[0]=true;
		for (int v : A[u]){
			if (coloracio[v]!=0) agafats[coloracio[v]]=true;
		}
		int c = 0;
		while(agafats[c]==true) ++c;
		coloracio[u] = c;
		colors = max(c,colors);
		
	}
}

int main(){
	int vertexs, arestes, u, v;
	while (cin >> vertexs >> arestes){
		Adj A(vertexs);
		for (int i = 0; i<arestes; ++i){
			cin >> u >> v;
			A[u].push_back(v);
			A[v].push_back(u);
		}
		int colors = 1;
	
		colora_graf(A,vertexs,colors);
		
		cout<< colors<<endl;
	}
}