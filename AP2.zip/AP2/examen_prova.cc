#include <iostream>
#include <vector>
#include <queue>
using namespace std;
using Mapa = vector<vector<char>>;
using Matrix = vector<vector<bool>>;

struct Point {
	int x,y;
};

vector<Point> veins (const Mapa& M, Point V){
	vector <Point> v;
	if (V.x+1 < M.size()) v.push_back({V.x+1,V.y});
	if (V.x-1 >=0) v.push_back({V.x-1,V.y});
	if (V.y+1 < M[0].size()) v.push_back({V.x,V.y+1});
	if (V.y-1 >=0) v.push_back({V.x, V.y-1});

	return v;
}

bool mante_distancia (const Mapa& M, Point U){
	vector <Point> v = veins (M,U);
	for (int i = 0; i<v.size(); ++i){
		if (M[v[i].x][v[i].y]=='M') return false;
	}
	return true;
}


bool es_pot_anar (Mapa& M, Point& inici){
	Matrix visitat (M.size(), vector<bool> (M[0].size(),false));
	queue <Point> Q;
	Q.push(inici);
	visitat [inici.x][inici.y]=true;
	while (!Q.empty()){
		Point V = Q.front();
		Q.pop();
		if (M[V.x][V.y]=='F') return true;
		for (Point i : veins(M,V)){
			if (M[i.x][i.y]!='M' and mante_distancia (M, i) and !visitat[i.x][i.y]){
				Q.push(i);
				visitat[i.x][i.y]=true;
			}
		}
	}
	return false;
}

int main(){
	int files, columnes;
	while(cin >> files >> columnes){
		Mapa M (files, vector<char>(columnes));

		Point inici; // posicions inici
		for (int i=0; i<files; ++i){
			for (int j=0; j<columnes; ++j){
				cin>>M[i][j];
				if (M[i][j]=='I'){
					inici.x=i;
					inici.y=j;
				}

			}
		}

		if (es_pot_anar(M,inici)) cout<< "SI" << endl;
		else cout << "NO" << endl;
	}
}