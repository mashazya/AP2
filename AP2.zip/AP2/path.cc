#include <iostream>
#include <vector>
using namespace std;
using Matriu_adjacencies = vector<vector<int>>;



void hi_ha_cami (Matriu_adjacencies& E, int i, int y, vector<bool>& visited, bool& no){
	if (E[i][y]==1){
		no=true;
	}
	else{
		for (int j=0; j<visited.size(); ++j){
			if (E[i][j]==1 and visited[j]==false){
				visited[j]=true;
				hi_ha_cami(E,j,y,visited,no);
			}
		}
	}
	
}

int main(){
	int m,n;
	cin >>n>>m;
	Matriu_adjacencies E (n, vector <int> (m,0));
	for (int i =0; i<m; ++i){
		int v1,v2;
		cin>>v1>>v2;
		E [v1][v2]=1;
	}
	int x,y;
	cin >> x >>y;
	vector <bool> visited (m,false);
	bool  no = false;
	hi_ha_cami(E,x,y,visited,no);
	if (not no) cout << "no" <<endl;
	else cout << "yes" <<endl;
	
}