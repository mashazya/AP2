#include <iostream>
#include <map>
#include <string>
using namespace std;

int main(){
	string name;
	string action;
	map <string, int> c;
	map <string, int> left;

	while (cin>>name){
		cin>>action;
		if (action=="enters"){
			if (c.count(name)>0) cout<< name <<" is already in the casino"<<endl;
			else c.insert({name, 0});
		}
		else if (action=="leaves"){
			if (c.count(name)==0) cout << name << " is not in the casino"<<endl;
			else {
				cout<< name << " has won " << c[name]<<endl;
				c.erase(name);
			}
		}
		else if (action=="wins"){
			int win;
			cin>>win;
			if (c.count(name)==0) cout<< name <<" is not in the casino"<<endl;
			else c[name]=c[name]+win;
		}

	}
	cout<<"----------"<<endl;
	for (auto e : c){
		cout << e.first << " is winning " << e.second <<endl;
	}

}