#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;
using Matrix = vector<vector<int>>;

Matrix mod (Matrix& M,int m){
	for (int i = 0; i<M.size(); ++i){
		for (int j = 0; j<M.size(); ++j){
			M[i][j]=M[i][j]%m;
		}
	}
	return M;
}

Matrix exponent (Matrix M, int n, int m, Matrix u){
	if (n==0) return u;
	if (n%2==0){
		Matrix x = exponent(M, n/2, m,u);
		Matrix res(2,vector<int>(2));

		for (int i = 0; i<M.size(); ++i){
			for (int j = 0; j<M.size(); ++j){
				int suma=0;
				for (int k = 0; k<M.size(); ++k){
					suma=suma+(x[i][k]*x[k][j]);
				}
				res[i][j]=suma%m;
			}
		}
		return res;
	}
	else{
		Matrix x = exponent(M,n-1,m,u);
		Matrix res(2,vector<int>(2));
		for (int i = 0; i<M.size(); ++i){
			for (int j = 0; j<M.size(); ++j){
				int suma=0;
				for (int k = 0; k<M.size(); ++k){
					suma=suma+(M[i][k]*x[k][j]);
				}
				res[i][j]=suma%m;
			}
		}
		return res;
	}
	return M;
	/*else{
		int x = exponent(n, (k-1), m);
		return (n*x)%m;
	}*/
}

void resultat (Matrix M, int n, int m, Matrix u){
	Matrix x = exponent(M,n,m,u);
	for (int i = 0; i<M.size(); ++i){
		for (int j = 0; j<M.size(); ++j){
			if (j>0) cout<< " ";
			cout<<x[i][j];
		}
		cout<<endl;
	}
	cout<<"----------"<<endl;
}

int main(){
	int n,m;
	Matrix M (2,vector<int>(2));
	int i=1;
	int m1,m2,m3,m4;
	while(cin>>m1>>m2>>m3>>m4){
		Matrix M (2,vector<int>(2));
		M[0][0]=m1; M[0][1]=m2;
		M[1][0]=m3; M[1][1]=m4;

		Matrix u (2,vector<int>(2));
		u[0][0]=1;u[0][1]=0;
		u[1][0]=0;u[1][1]=1;
		cin>>n>>m;
		resultat(M,n,m,u);
	}
}