#include <iostream>
#include <sstream>
#include <queue>
#include <map>
using namespace std;

struct BinTree{
	int vertex;
	BinTree* left;
	BinTree* right;

	~BinTree()
    {
        delete left;
        delete right;
    }
};

using Tree = BinTree*;

Tree read_tree (){
	Tree T;
	int v;
	if(cin >> v and v != -1){
		Tree left = read_tree();
		Tree right = read_tree();
		T = new BinTree{v, left, right};
		return T;
	}
	return nullptr;
}

struct Level {
	Tree tree;
	int nivell;
};

int width (Tree& T){
	map<int,int> w;
	int max = 0;

	int nivell = 0;
	queue <Level> Q;
	Q.push({T,nivell});
	while (!Q.empty()){
		Level R = Q.front(); Q.pop();
		if (R.tree != nullptr){
			++w[R.nivell-1];
			if (w[R.nivell-1] > max) max = w[R.nivell-1];
			nivell = R.nivell+1;
			Q.push({R.tree->left, nivell});
			Q.push({R.tree->right, nivell});
		}
	}
	return max;
}

int main(){
	int trees;
	cin >> trees;
	for (int i = 0; i<trees; ++i){
		Tree T = read_tree();
		cout << width(T) <<endl;
		delete T;
	}
}