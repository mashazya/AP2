import networkx as nx
import osmnx as ox
from staticmap import *
import haversine as haversine

# structure used in get_directions(), in the vector directions.
# used for getting all the information between nodes of the shortest path


class Node:
    def __init__(self, src=None, mid=None, dst=None, current_name=None,
                 next_name=None, angle=None, length=None):
        self.src = src
        self.mid = mid
        self.dst = dst
        self.current_name = current_name
        self.next_name = next_name
        self.angle = angle
        self.length = length


# gets the graph from OpenStreetMap and returns it
# the edges' type is "drive", which means they are streets used by cars
def download_graph(place):
    G = ox.graph_from_place(place, network_type='drive', simplify=True)
    ox.geo_utils.add_edge_bearings(G)
    return G


# saves a graph in a file in pickle format
def save_graph(graph, filename):
    nx.write_gpickle(graph, filename)


# given the name of the file in pixel format where
# previously some graph has been stored it returns the stored graph
def load_graph(filename):
    G = nx.read_gpickle(filename)
    return G


# function used for debugging
# dislays an image of the specified graph
def print_graph(graph):
    # for each node and its information...
    for node1, info1 in graph.nodes.items():
        print(node1, info1)
        # for each adjacent node and its information...
        for node2, info2 in graph.adj[node1].items():
            print('    ', node2)
            # osmnx graphs are multigraphs
            # but we will just consider their first edge
            edge = info2[0]
            # we remove geometry information from edges
            # because we don't need it and take a lot of space
            if 'geometry' in edge:
                del(edge['geometry'])
            print('        ', edge)


# Finds the angle between the vectors with the formula:
# angle = arccos((vector_a*vector_c)/(||vector_a||*||vector_c||))
# we create vectors from mid to src and from mid to dst
# this way, we want to calculate the angle created in mid
def _get_angle(graph, src, mid, dst):
    edge_src_mid = graph.get_edge_data(src, mid)[0]
    edge_mid_dst = graph.get_edge_data(mid, dst)[0]
    angle = (edge_mid_dst['bearing'] - edge_src_mid['bearing'])
    return angle


# returns a tuple of names
# that corresponds to the nodes that form part of the route
def _get_names(graph, route):
    route_names = []
    try:
        route_names = (ox.geo_utils.get_route_edge_attributes(graph, route,
                       attribute='name'))
    except:
        print('error nom')
    return route_names


# returns a tuple of points of each node that form part of the route
# the tuple consists of a list of coordinates in format (x,y)
def _get_nodes_coordinates(graph, route):
    route_nodes = []
    for i in range(len(route)):
        # as the attributes of the nodes (lon and lat) are given
        # in the inverse order
        # they are appended the other way round
        route_nodes.append([graph.nodes[route[i]]['y'],
                           graph.nodes[route[i]]['x']])
    return route_nodes


# returns the length of the vector (src->mid) in metres
def _get_length(src, mid):
    length = haversine.haversine(src, mid, unit='m')
    return length


# precondition: source_location != destination_location
# returns a pair of vector:
# directions is a vector with structure Node in each position
# route_nodes is a vector of all the coordinates in the path with format (y, x)
# this way, the directions are done properly
# and the plot_directions() is also done correctly
def get_directions(graph, source_location, destination_location):
    # We consider that src and dst are given in (x, y) format
    origin = ox.geo_utils.get_nearest_node(graph,
                                           source_location, method='haversine',
                                           return_dist=False)
    destination = ox.geo_utils.get_nearest_node(graph, destination_location,
                                                method='haversine',
                                                return_dist=False)

    directions = []  # route that we will return
    route = nx.shortest_path(graph, origin, destination)
    # coordinates vector of the path nodes
    route_nodes = _get_nodes_coordinates(graph, route)
    # vector of path's node's names
    route_names = _get_names(graph, route)
    route_nodes.append(destination_location)
    i = 0
    source = (source_location[1], source_location[0])
    middle = route_nodes[0]
    destination = route_nodes[1]
    u = Node(src=source, mid=middle, dst=destination,
             current_name=None, next_name=route_names[0],
             angle=None, length=None)
    directions.append(u)
    cont_route_nodes = 2
    cont_route_names = 1

    # we get all the information of each node in the path
    while directions[-1].mid != destination_location:
        if i < len(route_nodes) - 3:
            angle = _get_angle(graph, route[i], route[i+1], route[i+2])
            i += 1
        else:
            angle = None

        src = directions[-1].mid
        mid = directions[-1].dst
        if (cont_route_nodes >= len(route_nodes)):
            dst = None
        else:
            dst = route_nodes[cont_route_nodes]
        cont_route_nodes += 1

        current_name = directions[-1].next_name
        if (cont_route_names < len(route_names)):
            next_name = route_names[cont_route_names]
        else:
            next_name = None
        cont_route_names += 1
        if (mid != destination_location):
            length = _get_length(src, mid)
        else:
            length = None

        v = Node(src, mid, dst, current_name, next_name, angle, length)
        directions.append(v)

    return directions, route_nodes


# swap_vector is used for swap the vector to get the format (x,y)=(lat,lon)
def _swap_vector(directions):
    for i in range(len(directions)):
        aux = directions[i][0]
        directions[i][0] = directions[i][1]
        directions[i][1] = aux


# DIRECTIONS - LIST OF POINTS IN FORMAT (x,y)
# plot_directions saves the image of the route defined in the direction tuple
# PARAMETERS:
# graph that contains src and dst
# source_location, destination_location -> start and end points
# given in the (x,y) format, do not have to be nodes
# directions -> a vector that contains the nodes of the route
# filename -> name of the file
# where the image of the route is stored
# width, height -> size of the image in pixels
# if not specified by default they are 400x400
def plot_directions(graph, source_location, destination_location,
                    directions, filename, width=400, height=400):

    route = StaticMap(width, height, padding_x=20, padding_y=20)
    # find the neares node to the source_location
    # to get the corrcet starting point
    origin = ox.geo_utils.get_nearest_node(graph, source_location,
                                           method='haversine',
                                           return_dist=False)

    # LINE
    del directions[-1]
    _swap_vector(directions)
    route.add_line(Line(directions, 'red', 2))
    for i in range(1, len(directions) - 1):
        marker = CircleMarker(directions[i], 'red', 4)
        route.add_marker(marker)

    # MARKER
    marker_start = IconMarker((source_location[1], source_location[0]),
                              'start.png', 12, 32)
    marker_end = IconMarker((destination_location[1], destination_location[0]),
                            'end.png', 12, 32)
    route.add_marker(marker_start)
    route.add_marker(marker_end)

    # SAVE IMAGE
    image = route.render()
    image.save(filename, 'png')
