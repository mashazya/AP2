from telegram.ext import Updater, CommandHandler, MessageHandler, Filters
import guide as guide
import os
import random

TOKEN = open('token.txt').read().strip()
updater = Updater(token=TOKEN, use_context=True)
dispatcher = updater.dispatcher
#G = guide.download_graph("Barcelona,Spain")
#guide.save_graph(G, "Barcelona")

def start(update, context):
	context.bot.send_message(chat_id=update.effective_chat.id, text="Hello, amigo! My name is Extraordinary Man.\nType /help to know more about the available commands")

dispatcher.add_handler(CommandHandler('start', start))

def _has_all_information(update, context):
	if 'location' not in context.user_data:
		context.bot.send_message(chat_id=update.effective_chat.id,text="Send me your current location📍, please\nAfter this, type /go and your destination🌍")
		return False
	return True
def _angle_direction(update, context, angle):
	if (angle < 22.5 and angle > -22.5):
		return 'straight'
	elif (angle < 67.5 and angle >= 22.5):
		return 'half right'
	elif (angle < 112.5 and angle >= 67.5):
		return 'right'
	elif (angle >= 112.5):
		return 'strong right'
	elif (angle > -67.5 and angle <= -22.5):
		return 'half left'
	elif (angle > -112.5 and angle <= -67.5):
		return 'left'
	return 'strong left'


def _write_directions(update, context):
	directions = context.user_data['directions']
	i = context.user_data['counter']
	print("Hello1")
	if i<len(directions)-1:
		angle = _angle_direction(update, context, directions[i].angle)
		print("Hello2")
		text1 = "Well done: You have reached checkpoint #" + i + "\nYou are at " + str(context.user_data['location'][0]) + ", " + str(context.user_data['location'][1]) + "\nGo to checkpoint #" + (i+1) + ": " + str(directions[i].mid[1]) + ", " + str(directions[i].mid[0])
		print("Hello3")
		if directions[i].next_name != None:
			text1 += "(" + str(directions[i].next_name) + ")"		
		text2 = "Go " + str(angle) + " through " + str(directions[i].current_name) + str(directions[i].length) + " meters."
		context.bot.send_message(chat_id=update.effective_chat.id,text=text1)
		context.bot.send_message(chat_id=update.effective_chat.id,text=text2)
		context.user_data['counter'] += 1
	if i==len(directions)-1:
		text = "You have arrived to your destination!"
		context.bot.send_message(chat_id=update.effective_chat.id,text=text)

def go(update, context):
	context.user_data['source_location'] = context.user_data['location']
	if _has_all_information(update, context):
		print('hello')
		if 'city' in context.user_data:
			city = context.user_data['city']
		else:
			city = 'Barcelona'
		Graph = guide.load_graph(city)
		print("hello")
		src = context.user_data['source_location']
		print(str(src))
		try:
			dst = guide.ox.geocode(update.message.text[4:])
			print(str(dst))
		except:
			context.bot.send_message(chat_id=update.effective_chat.id,text="Can't find your destination, check the spelling!")

		#guide.save_graph(G,'prova')
		try:
			directions,route_nodes = guide.get_directions(Graph,src,dst)
		except:
			context.bot.send_message(chat_id=update.effective_chat.id,text="There is no route from where you are to your destination!🤨\nTry to change your city with the /mycityis command")
		print(str(route_nodes))
		context.user_data['directions'] = directions
		context.user_data['route_nodes'] = route_nodes
		context.user_data['counter'] = 1
		name = "%d" % random.randint(1000000, 9999999)
		print(str(name))
		guide.plot_directions(Graph,src,dst,route_nodes, name)
		print('hello')
		context.bot.send_photo(chat_id=update.effective_chat.id, photo=open(name, 'rb'))
		print('hello')

		text="You are at: " + str(directions[0].src[0]) + ", " + str(directions[0].src[1]) +'\nStart at checkpoint #1: '+ str(directions[0].mid[1]) + ", " + str(directions[0].mid[0])
		if directions[0].next_name != None:
			text += "(" + directons[0].next_name + ")"
		context.bot.send_message(chat_id=update.effective_chat.id,text=text)

		#os.remove('telegram_route')
dispatcher.add_handler(CommandHandler('go', go))

def mycityis (update, context):

	city = update.message.text[10:]
	context.user_data['city'] = city
	context.bot.send_message(chat_id=update.effective_chat.id, text="Downloading the city of " + city + "...")
	G = guide.download_graph(city)
	guide.save_graph(G, city)
	context.bot.send_message(chat_id=update.effective_chat.id, text="Now your city is " + city)
dispatcher.add_handler(CommandHandler('mycityis', mycityis))


def help(update, context):
	context.bot.send_message(chat_id=update.effective_chat.id, text="/start : initializes the dialogue")
	context.bot.send_message(chat_id=update.effective_chat.id, text="/author : writes the name of my parents, my creators")
	context.bot.send_message(chat_id=update.effective_chat.id, text="/go : type this command and your destination to create a route")
	context.bot.send_message(chat_id=update.effective_chat.id, text="/cancel : kills me")
dispatcher.add_handler(CommandHandler('help', help))

def where(update, context):
    message = update.edited_message if update.edited_message else update.message
    lat,lon = message.location.latitude, message.location.longitude
    location = [lat, lon]
    context.user_data['location'] = location
   	# envia la localització al xat del client
dispatcher.add_handler(MessageHandler(Filters.location, where))

def cancel(update,context):
	global user_city
	del context.user_data['source']
	del user_city[update.effective_chat.id]
dispatcher.add_handler(CommandHandler('cancel', cancel))


def author(update, context):
	context.bot.send_message(chat_id=update.effective_chat.id, text="My parents are:\nNúria Cantero and Maria Zyatyugina")
dispatcher.add_handler(CommandHandler('author', author))

updater.start_polling()