from telegram.ext import Updater, CommandHandler, MessageHandler, Filters
import guide as guide
import os
import random

TOKEN = open('token.txt').read().strip()
updater = Updater(token=TOKEN, use_context=True)
dispatcher = updater.dispatcher
G = guide.download_graph("Barcelona,Spain")
guide.save_graph(G, "Barcelona")


# it initializes the bot, sending a message and offering the /help command.
def start(update, context):
    text = "Hello, amigo! My name is Extraordinary Man.\n"
    text += "Type /help to know more about the available commands"
    context.bot.send_message(chat_id=update.effective_chat.id, text=text)


# gives information about all the public functions
# that you can call and how to use them
def help(update, context):
    chat_id = update.effective_chat.id

    text_loc = "In order to make your life easier, share your live location. "
    text_loc += "This way, I can guide you better during your route."
    context.bot.send_message(chat_id=chat_id, text=text_loc)
    text_start = "/start : initializes the dialogue"
    context.bot.send_message(chat_id=chat_id, text=text_start)
    text_author = "/author : writes the name of my parents, my creators"
    context.bot.send_message(chat_id=chat_id, text=text_author)
    text_city = "/mycityis : let me know which city are you in. "
    text_city += "For example: /mycityis Tarragona. "
    text_city += "By default, it is set to Barcelona. "
    text_city += "Only type this command when necessary."
    context.bot.send_message(chat_id=chat_id, text=text_city)
    text_go = "/go : type this command and your destination to create a route."
    text_go += " For example: /go Rambla Catalunya, Barcelona"
    context.bot.send_message(chat_id=chat_id, text=text_go)
    context.bot.send_message(chat_id=chat_id, text="/cancel : kills me")


# sends the authors' names
def author(update, context):
    parents = "My parents are:\nNúria Cantero and Maria Zyatyugina"
    context.bot.send_message(chat_id=update.effective_chat.id, text=parents)


# If you are not located in Barcelona,which is the city set by default,
# you can call this command to change it
# Each user has their city. It is saved in the map context.user_data
def mycityis(update, context):
    city = update.message.text[10:]
    if len(city) == 0:
        texy = "Type /mycityis your_city"
        context.bot.send_message(chat_id=update.effective_chat.id, text=text)
        return
    # map used during all the program
    context.user_data['city'] = city
    text = "Downloading the city of " + city + "..."
    context.bot.send_message(chat_id=update.effective_chat.id, text=text)
    # downloads and saves the graph of the city written by the user
    G = guide.download_graph(city)
    guide.save_graph(G, city)
    text = "Now your city is " + city
    context.bot.send_message(chat_id=update.effective_chat.id, text=text)


# auxiliar private function for /go. It checks if the bot has all the
# necessary information to run the /go command
# in order to return true, it must have the location of the user
def _has_all_information(update, context):
    if 'location' not in context.user_data:
        text = "Send me your current location📍, "
        text += "please\nAfter this, type /go and your destination🌍"
        context.bot.send_message(chat_id=update.effective_chat.id, text=text)
        return False
    return True


# command typed by the user to get the route they want
# the user must type /go destiny_place
# by the source location the program establishes the star location of the user
# destiny location is set to the place specified in the command
def go(update, context):
    if _has_all_information(update, context):
        chat_id = update.effective_chat.id

        context.user_data['source_location'] = context.user_data['location']
        # checks if the city has changed with /mycityis
        if 'city' in context.user_data:
            city = context.user_data['city']
        else:
            city = 'Barcelona'
        Graph = guide.load_graph(city)
        src = context.user_data['source_location']
        try:
            dst = guide.ox.geocode(update.message.text[4:])
        except:
            error = "Can't find your destination, "
            error += "check the spelling or type the destination!"
            context.bot.send_message(chat_id=chat_id, text=error)

        try:
            directions, route_nodes = guide.get_directions(Graph, src, dst)
        except:
            error = "There is no route from where you are to your destination!"
            error += " 🤨\nTry to change your city with the /mycityis command"
            context.bot.send_message(chat_id=chat_id, text=error)

        context.user_data['directions'] = directions
        context.user_data['route_nodes'] = route_nodes
        context.user_data['counter'] = 1

        # gets a random number that will be used for the name of the photo
        name = "%d" % random.randint(1000000, 9999999)

        # generates the image of the route
        guide.plot_directions(Graph, src, dst, route_nodes, name)
        context.bot.send_photo(chat_id=chat_id, photo=open(name, 'rb'))

        # removes the generated image from the server
        os.remove(name)

        # sends the first update of the user's location
        text = "You are at: " + str(directions[0].src[0])
        text += ", " + str(directions[0].src[1])
        text += '\nStart at checkpoint #1'
        name = directions[0].next_name
        if directions[0].next_name is not None:
            text += ' at ' + name + ', '
        text += 'located at: ' + str(directions[0].mid[1])
        text += ", " + str(directions[0].mid[0])
        context.bot.send_message(chat_id=chat_id, text=text)


# the function that gets the user current location in real time automatically
# the where function is not a command that can be called by the user,
# it is only used for checking the location updates
def where(update, context):
    try:
        sms = update.edited_message if update.edited_message else update.message
    except:
        print('error shared location')
        text = 'Start sharing again your live location, please🙏🏻'
        context.bot.send_message(chat_id=chat_id, text=text)

    lat, lon = sms.location.latitude, sms.location.longitude
    location = (lat, lon)
    context.user_data['location'] = location
    if 'directions' in context.user_data:
        i = context.user_data['counter']
        if guide._get_length([location[1], location[0]],
           context.user_data['directions'][i].src) <= 10:
            _write_directions(update, context)

dispatcher.add_handler(MessageHandler(Filters.location, where))


# it returns the direction the user should follow to get to the next node
# it is based on the image in the
# explanation made by the teachers of this project
def _angle_direction(angle):

    if (angle is None):
        return ''
    if(angle < 22.5 and angle > -22.5):
        return 'straight'
    elif (angle < 67.5 and angle >= 22.5):
        return 'half right'
    elif (angle < 112.5 and angle >= 67.5):
        return 'right'
    elif (angle >= 112.5):
        return 'strong right'
    elif (angle > -67.5 and angle <= -22.5):
        return 'half left'
    elif (angle > -112.5 and angle <= -67.5):
        return 'left'
    elif (angle <= -112.5):
        return 'strong left'


# it returns an integer value, which is the aproximation of the length
# between two nodes
# this way, the user only sees a number without decimals
# instead of a number with 10 decimals
def _aprox_length(length):
    res = length - length % 1
    if length % 1 >= 0.5:
        res += 1
    return res


# This private function is implemented in order to send messages to the user
# It is called only when the used had arrived to a new node
# thus to send an update
# with the actual location and the indication for the user to follow the route
# when the user arrives to it destination
# the function indicates so and finishes
# the guiding by calling the cancel () funtion
def _write_directions(update, context):
    directions = context.user_data['directions']
    # counter private for every user and set in /go
    i = context.user_data['counter']

    # the user hasn't finished the route
    if i < len(directions)-1:
        angle = _angle_direction(directions[i-1].angle)

        # gets the first text to send to the user
        text1 = "🙌 Well done: You have reached checkpoint #" + str(i)
        text1 += "\nYou are at " + str(context.user_data['location'][0])
        text1 += ", " + str(context.user_data['location'][1])
        text1 += "\nGo to checkpoint #" + str(i+1)
        if directions[i].next_name is not None:
            text1 += " at " + str(directions[i].next_name) + ","
        text1 += " located at: " + str(directions[i].mid[1])
        text1 += ", " + str(directions[i].mid[0])

        # gets the second text the bot sends the user
        text2 = "Go"
        if angle != '':
            text2 += " " + str(angle)
        if directions[i].current_name is not None:
            text2 += " through " + str(directions[i].current_name)
        if directions[i].length is not None:
            length = _aprox_length(directions[i].length)
            text2 += " " + str(length) + " metres."

        context.bot.send_message(chat_id=update.effective_chat.id, text=text1)
        context.bot.send_message(chat_id=update.effective_chat.id, text=text2)
        # the user got to the next node of the route
        context.user_data['counter'] += 1

    if i == len(directions)-1:  # the user has finished the route
        text = "You have arrived to your destination!"
        context.bot.send_message(chat_id=update.effective_chat.id, text=text)
        cancel(update, context)


# deletes the route the user asked for
# only used when the user no longer wants to follow the route
# or when the user arrives to their destination
def cancel(update, context):
    text = "Bye bye! 👋 Don't get lost!"
    context.bot.send_message(chat_id=update.effective_chat.id, text=text)
    del context.user_dat['directions']
    del context.user_data['route_nodes']
    del context.user_data['source_location']

# Link the functions to the /any_command for the user to be able to call them
dispatcher.add_handler(CommandHandler('start', start))
dispatcher.add_handler(CommandHandler('help', help))
dispatcher.add_handler(CommandHandler('author', author))
dispatcher.add_handler(CommandHandler('mycityis', mycityis))
dispatcher.add_handler(CommandHandler('go', go))
dispatcher.add_handler(CommandHandler('cancel', cancel))

updater.start_polling()
