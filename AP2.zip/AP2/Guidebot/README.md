
# GUIDEBOT EXTRAORDINARY MAN

  

&ensp;&ensp;&ensp;&ensp;This project aims to design a Telegram bot that gives directions to a user to a specified place guiding it through the whole route. The bot is able to answer to certain commands (go, author, mycityis and cancel which will be explained later).

&ensp;&ensp;&ensp;&ensp;The code consists of two parts (guide.py and bot.py). The guide file contains all the functions needed to construct the route to the specified destination and to create an image of the path that the user will have to go through. The second part is the bot file which is the base of the Telegram bot, thus it contains all the commands related to the message sending and guiding the user correctly. To ensure the correct functioning of the bot the user will have to share its live location in the chat to get the correct directions, otherwise the bot will not detect any movement.

## Installation

&ensp;&ensp;&ensp;&ensp;The code is based on three main libraries - networkx, osmnx and staticmap. In order to get the program running correctly, please, install them by running the commands specified in the requirements.txt file. To install the required libraries please run the following command: ```pip install -r requirements.txt```

  

&ensp;&ensp;&ensp;&ensp;As osmnx library requires the installation of an extra library which installation varies depending on your OS, please, run one of the following command separately.

```brew install spatialindex``` (for Mac)

```apt install libspatialindex-dev``` (for Ubuntu)

  

## Usage

&ensp;&ensp;&ensp;&ensp;Save the two files (guide.py and bot.py) and the two images provided (start.png and end.png) in the same directory.

&ensp;&ensp;&ensp;&ensp;Run the bot.py file in your terminal. Make sure to be the only person to do this as you will become the server for the bot. As the bot is oriented to be multi user, any person can access to it through the link:

[http://t.me/Extraordinary_man_bot](http://t.me/Extraordinary_man_bot)

&ensp;&ensp;&ensp;&ensp;However the server is a unique computer which will receive all the updates of all the users running the bot.

  

## Giving instructions

&ensp;&ensp;&ensp;&ensp;All the commands have to be executed with the ‘/’ symbol right before the keyword. With this symbol, you indicate that you are asking for something. All the available commands can be consulted by running ```/help``` at any moment and other commands will be ignored.

&ensp;&ensp;&ensp;&ensp;When want to start a new guidance, type ```/go place_you_want_to_go.``` Check that the name is unique as for example: ```/go Sagrada Familia```, otherwise, please, specify the city where the place of interest is located, for example: ```/go Plaça Catalunya, Barcelona```.

  
  

## Example

&ensp;&ensp;&ensp;&ensp;After accessing to the chat and clicking the Start/Restart button, the ```/start``` command will be executed automatically.


<p align="center"><img src="https://lh5.googleusercontent.com/vW1BDN2WnDsEJ2T__ACp8F5sHbgFHoeYttMK2-CdufkItCqEWwtd1M0yBzQR2CiptV53mFznDhlKSl3KurbuMjJqH41nED2PkhVrL5TTorgVPyDBPqMG1DLdXiC5o1K1B8mqDJoy" width="300"></p>

&ensp;&ensp;&ensp;&ensp;Please, be aware that, by default, the city is set to Barcelona; so in case you want to change your city to any other, the ```/mycityis name_of_the_city``` has to be executed. Try to avoid changing your city very frequently as the download action is very complex and can affect other users.

&ensp;&ensp;&ensp;&ensp;From this point you can start chatting with the bot. Share your life location at the moment and keep it during the whole route. Next, enter your destination and you will immediately start to receive notifications on how to get to your destination.

<img src="https://lh4.googleusercontent.com/Y0luMzDA3zPj6QwcqDYWI3zdGnSI545KlnQQ22UDWwprTZsos_H08ntwUF29l7e0YJtf82c7oc__RoKOUaZyLNO3hr9H-wYZgoq1uGO_7MAemOnKSBwmWKUX2CC-kRh8WCp-Mxbo" width="300">
<img src="https://lh6.googleusercontent.com/BQN8kG5lZeWFjzzv7dEngMwCwalTX53YUDaCoE9SdoP7wp27RTtTej0PI69Fiz6QECgppg0zgs-zzJM_7HR2WGfZE-nvD_CxF891ievYIhMIM9f649rXUBiZ69XGvFlGaxIYoKtf" width="300">
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  


&ensp;&ensp;&ensp;&ensp;The accuracy of your location is 10m, so the directions may be slightly affected depending on the way you follow the route.

&ensp;&ensp;&ensp;&ensp;In case you wanted to stop the guiding, execute the ```/cancel``` command which will make the bot forget your route and stop sending you directions.

  

## Deployment

&ensp;&ensp;&ensp;&ensp;Mocklocations is a useful app that can be downloaded from GogglePlay to simulate location and movement of a user in order to check if the route is well constructed and the directions are well given without leaving your house.

  

## Authors

  

-   Nuria Cantero Montañà
    
-   Maria Zyatyugina