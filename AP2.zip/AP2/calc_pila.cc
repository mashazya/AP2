#include <iostream>
#include <stack>
#include <cctype>
#include <string>
using namespace std;

int convierte_en_num (const string& c){
	int k=1;
	int res=0;
	for (int i = c.size()-1; i>=0; --i){

		res=res+((c[i]-'0')*k);
		k=k*10;
	}

	return res;
}

int main(){
	stack <int> pila;
	string c;

	while(cin>>c){
		if (isdigit(c[0])) {
			if (c.size()>1) pila.push(convierte_en_num(c));
			else pila.push(c[0] -'0');
		}
		else{
			int x = pila.top();
			pila.pop();


			int y =  pila.top();
			pila.pop();


			if (c[0]=='+') pila.push(x+y);
			if (c[0]=='-') pila.push(y-x);
			if (c[0]=='*') pila.push(x*y);
		}
	}
	stack <int> resultats;
	while(not pila.empty()){
		resultats.push(pila.top());
		pila.pop();
	}
	while(not resultats.empty()){
		cout<<resultats.top()<<endl;
		resultats.pop();

	}

}



