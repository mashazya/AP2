#include <iostream>
#include <vector>
using namespace std;
using Matrix = vector<vector<int>>;

int fibonacci(int n, int m){
	if (n==1) return 1;
	else{

	}
}

void fib(int n, int m){
	cout<<fibonacci(n,m)<<endl;
}

int main(){
	int n,m;
	while(cin>>n>>m){
		fib(n,m);
		Matrix M(2,vector<int>(2));
		M[0][0]=1; M[0][1]=1;
		M[1][0]=1; M[1][1]=0;
	}
}