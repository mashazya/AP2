/******************************************************************************

Estratègia utilitzada per l'algorisme:
    Per trobar el minim dels màxims he escrit l'algorisme semblant
    a la cerca binària però en cop de buscar un element buscava un limit,
    en el cas d'aquest programa el punt mig era el limit (superior o inferior)
    depenent del vector. No calia que estigues ordenat, ja que l'unic que
    importa és la suma de cadascuna de les parts

Eficiència de l'algorisme: O(nlog s) on s es la suma total inicial

Explicació de l'eficiència:
    Considero eficient aquest algorisme, ja que el fet de reduir la suma del vector
    en parts i quedar-nos només amb una d'elles. s és la suma del principi que s'agafa 
    com punt final al principi del programa

******************************************************************************/

#include <cassert>
#include <iostream>
#include <vector>

using namespace std;

// returns whether v has a max-sum in m parts ≤ x
bool has_max_sum(const vector<int>& v, int m, int x)
{
    int parts = 1;//particions del vector
    int sum = 0;
    for (int i = 0; i<v.size(); ++i){
        if (v[i]>x) return false;
        sum += v[i];
        if (sum>x){
            ++parts;
            if (parts>m) return false;
            sum = v[i];
        }
    }
    return true;
}
int suma (const vector<int>& v){
    int suma = 0;
    for (int i = 0; i<v.size(); ++i){
        suma += v[i];
    }
    return suma;
}
// returns the min-max-sum of a vector for m parts
int min_max_sum(const vector<int>& v, int m)
{
    int s = suma(v); // suma de tots els elements del vector
    int min = 0; //limit inferior
    int max = s; //limit superior
    while (min < max){
        int mitjana = (min + max)/2;
        if (has_max_sum(v,m,mitjana)){
            max = mitjana;
        }
        else {
            min = mitjana+1;
        }
    }
    return max; 
}

// main program
int main()
{
    int m, n;
    while (cin >> m >> n) {
        vector<int> v(n);
        for (int& x : v) {
            cin >> x;
        }
        cout << min_max_sum(v, m) << endl;
    }
}
