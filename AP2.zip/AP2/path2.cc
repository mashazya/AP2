#include <iostream>
#include <vector>
#include <string>
using namespace std;
using Matriu_adjacencies = vector<vector<int>>;



void hi_ha_cami (Matriu_adjacencies& E, int i, int y, vector<bool>& visited, bool& no){
	if (E[i][y]==1){
		no=true;
	}
	else{
		for (int j=0; j<visited.size(); ++j){
			if (E[i][j]==1 and visited[j]==false){
				visited[j]=true;
				hi_ha_cami(E,j,y,visited,no);
			}
		}
	}
	
}

int main(){
	int n;
	cin >>n;
	vector <string> vertex(n);
	for (int i=0;i<n;++i){
		cin>>vertex[i];
	}
	int m;
	cin>>m;
	Matriu_adjacencies E (n, vector <int> (m,0));
	for (int i=0;i<m;++i){
		string v1, v2;
		cin >>v1>>v2;
		int k,l;
		for (int j=0; j<n; ++j){
			if (v1==vertex[j]) k=j;
			if (v2 == vertex [j]) l = j;
		}
		E[k][l]=1;
	}
	string x,y;
	cin >> x >> y;
	int scr, dest;
	for (int j=0; j<n; ++j){
		if (x==vertex[j]) scr=j;
		if (y == vertex [j]) dest = j;
	}
	vector <bool> visited (m,false);
	bool  no = false;
	hi_ha_cami(E,scr,dest,visited,no);
	if (not no) cout << "no" <<endl;
	else cout << "yes" <<endl;

	
}