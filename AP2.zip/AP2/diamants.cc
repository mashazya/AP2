#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

bool espot (int n, int v, vector<int>& diamants){
	sort(diamants.begin(), diamants.end());
	int i = 0, j = n-1;
	while (i<j){
		int suma=0;
		suma = diamants[i]+diamants[j];
		if (suma>v) --j;
		else if (suma<v)++i;
		else return true;
	}
	return false;

}

int main(){
	int v,n;
	while(cin>>v>>n){
		if (n==0 and v == 0) return 0;
		vector <int> diamants(n);
		for (int i = 0; i<n; ++i){
			cin>>diamants[i];
		}
		if (espot(n,v,diamants)) cout<<"married"<<endl;
		else cout<<"single"<<endl;
	}
}