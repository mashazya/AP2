#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int simpify (vector <int>& v, int left, int right){
	if (left>=right) return 0;
	
	int mid = (left+right)/2;
	int counter1=simpify(v,left,mid);
	int counter2=simpify(v,mid+1,right);

	vector <int> aux(right-left+1);
	int k = 0;
	int i=left;
	int j= mid+1;
	int counter3=0;
	while (i<= mid and j<=right){
		if (v[i]<=v[j]){
			aux[k]=v[i];
			++k;
			++i;
		}
		else {
			aux[k]=v[j];
			++k;
			counter3= counter3 + (mid+1-i);
			++j;
		}
	}
	while (i<=mid){
		aux[k]=v[i];
		++k;
		++i;
	}
	while (j<=right){
		aux[k]=v[j];
		++k;
		++j;
	}

	for (int k = 0; k < right-left+1; ++k) {
        v[left+k] = aux[k];
    }

	return counter1+counter2+counter3;
}

int main(){
	int n;
	while(cin>>n){
		vector<int> v(n);
		for (int i=0; i<n; ++i){
			cin>>v[i];
		}
		int counter=simpify(v,0,n-1);
		cout<< counter<<endl;
	}
}