#include <iostream>
#include <queue>
#include <stack>
#include <vector>
#include <string>
#include <iomanip>
using namespace std;

double calcula (priority_queue <double, vector<double>, greater<double>>& fq){
	double ans=0;
	while(fq.top()!=100){
		double x = fq.top(); fq.pop();
		double y = fq.top(); fq.pop();
		ans= ans+(x+y)/100;
		fq.push(x+y);
	}
	return ans;

}

void escriu (double n){
	cout<< "nombre esperat de bits per lletra: "<< n << endl;
}

int main(){
	cout.setf(ios::fixed);
	cout.precision(4);

	int n;
	cin>>n;

	priority_queue <double, vector<double>, greater<double>> fq;
	double x;
	for (int i=0; i<n; ++i){
		cin>>x;
		fq.push(x);
	}
	escriu(calcula(fq));
}




