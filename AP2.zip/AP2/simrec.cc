#include <iostream>
#include <stack>
#include <cctype>
#include <string>
using namespace std;

void work(int n) {
	if (n==1)cout<< " 1";
	else{
		stack <int> pila;
		pila.push(1);
		stack <int> copia;
		stack <int> copia2;
		for (int k=1; k<n; ++k){
			while (not pila.empty()){
				copia.push(pila.top());
				copia2.push(pila.top());
				pila.pop();
			}
			for (int i=0; i<2; ++i){
				while (not copia.empty()){
					pila.push(copia.top());
					copia.pop();
				}
				while (not copia2.empty()){
					pila.push(copia2.top());
					copia2.pop();
					
				}
			}
			pila.push(k+1);
		}

		while(not pila.empty()){
			cout<< " "<< pila.top();
			pila.pop();
		}
	}
}
 
     int main() {
         int n;
         while (cin >> n) {
             work(n);
             cout << endl;
         }
     }