#include <iostream>
#include <vector>
#include <cassert>
#include <map>
#include <string>
#include <algorithm>
#include <utility>
using namespace std;

struct Players{
	string name;
	int elo;
};

bool ordena (const Players & a, const Players & b){
	if (a.elo != b.elo) return a.elo > b.elo;
	return a.name < b.name;
}

int main(){
	string comand;
	map <string, int> online;
	map <string, int> offline;
	vector<Players> v;
	while (cin >> comand){

		if (comand=="LOGIN"){
			string name;
			cin >> name;
			if(offline.count(name)<1){
				online.insert({name,1200});
			}
			else if (offline.count(name)>=1){
				auto it = offline.find(name);
				online.insert(*it);
				offline.erase(name);

			}


		}
		if (comand=="LOGOUT"){
			string name;
			cin >> name;
			
			auto it = online.find(name);
			if (it!=online.end())
				offline.insert({name,it->second});
				online.erase(name);
			

		}
		if (comand=="PLAY"){
			string player1, player2;
			cin >> player1 >> player2;
			if(online.count(player1)==1 and online.count(player2)==1){
				auto it = online.find(player1);
				it->second += 10;
				//cout << "SUMO 10=" <<it->second<<endl;
				it = online.find(player2);
				if (it->second - 10 >= 1200) it->second -= 10;

			}
			else cout<<"player(s) not connected"<<endl;

		}
		if (comand=="GET_ELO"){
			string name;
			cin >> name;
			if(online.count(name)==1){
				auto it = online.find(name);
				cout << it->first << " " << it->second << endl;
			}
			else if(offline.count(name)==1) {
				auto it = offline.find(name);
				cout << it->first << " " << it->second << endl;
			}

			else cout<<"player(s) not connected"<<endl;

		}


	}

	for (auto it : online){
			v.push_back({it.first,it.second});
	}
	for (auto it:offline){
		v.push_back({it.first,it.second});
	}

	sort(v.begin(), v.end(), ordena);

	cout << endl<<"RANKING"<<endl;
	for (int i = 0; i<v.size(); ++i){
		cout<< v[i].name << " " << v[i].elo << endl;
	}

}

