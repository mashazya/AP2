#include <iostream>
#include <vector>
#include <cmath>
using namespace std;
using Matrix = vector<vector<int>>;

struct Circle{
	double x,y,r;
};

int quants_salts (Matrix& Adj, int i, int fin, vector<bool>& visited,int& contador){
	if (Adj[i][fin]==1){
		++contador;
		return contador;
	}
	else {
		for (int k=0; k<visited.size(); ++k){
			if (Adj[i][k]==1 and not visited[k]){
				visited[k]=true;
				++contador;

				return quants_salts(Adj,k,fin,visited,contador);
			}
		}
		return 0;
	}
}

int main(){
	int n,d;
	while(cin >> n >> d){
		vector<Circle> rocas;
		for (int i = 0; i<n; ++i){
			double x,y,r;
			cin >> x>>y>>r;
			rocas.push_back({x,y,r});
		}

		Matrix Adj (n, vector<int> (n,0));
		for (int i =0 ; i<rocas.size()-1; ++i){
			for (int j =i+1 ; j<rocas.size(); ++j){
				if (abs(rocas[i].x-rocas[j].x)<=d and abs(rocas[i].y-rocas[j].y)<=d){
					double dx = (rocas[j].x-rocas[i].x)*(rocas[j].x-rocas[i].x);
					double dy = (rocas[j].y-rocas[i].y)*(rocas[j].y-rocas[i].y);
					if ((sqrt(dx+dy)-rocas[j].r-rocas[i].r)<=d){
						Adj[i][j]=1;

					}
				}
			}
		}

		vector <bool> visited (n,false);
		int contador = 0;
		salts 
		if (salts==0) cout<<"Xof!"<<endl;
		else cout<< contador<<endl;

	}
}