#include <iostream>
#include <vector>
#include <stack>
#include <string>
#include <stdio.h> 
using namespace std;

struct BinTree{
	string paraula;
	BinTree* left;
	BinTree* right;
	int nivell;
	~BinTree(){
		delete left;
		delete right;
	}
};

using Tree = BinTree*;

Tree read_tree (int nivell){
	string v;
	cin >> v;
	if (v == "-1") return nullptr;
	else{
		++nivell;
		Tree left = read_tree(nivell);
		Tree right = read_tree(nivell);
		return new BinTree{v,left,right,nivell};
	}
}

void escriu_espais(Tree& T){
	int contador = 10* T->nivell - T->paraula.size();
	for (int i = 0; i < contador; ++i){
		cout << " ";
	}
}

void print_tree(Tree&T){
	if (T != nullptr){
		print_tree(T->right);
		escriu_espais(T);
		cout << T->paraula <<endl;
		print_tree(T->left);
	}
}

int main(){
	int nivell = 0;
	Tree T = read_tree(nivell);
	print_tree(T);
	delete T;
}

