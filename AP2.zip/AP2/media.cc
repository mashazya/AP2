#include <iostream>
#include <set>
#include <string>
using namespace std;

int main(){
	string w;
	set <string> s;
	cin>>w;
	s.insert(w);
	auto mig = s.find(w);
	if (w!="END") {
		cout<< *mig<< endl;
		while (cin>>w and w!="END"){
			s.insert(w);
			if (w<*mig and s.size()%2==0) --mig;
			if (w> *mig and s.size()%2!=0) ++mig;
			cout<< *mig<< endl;

		}
	}

}