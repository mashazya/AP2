#include <iostream>
#include <vector>
#include <string>
#include <algorithm>
#include <queue>
#include <map>
using namespace std;

struct Paraules{
	string s;
	int n;
};

bool ordena (const Paraules& a, const Paraules& b){
	if (a.n == b.n) return a.s < b.s;
	return a.n < b.n;

}

int main(){
	string word;
	map <string, int> paraules;
	while (cin>>word){
		if (paraules.count(word)==1){
			auto it = paraules.find(word);
			++it -> second;
		}
		else paraules.insert({word,1});
	}
	
	auto it = paraules.begin();
	vector <Paraules> v;
	while (it!=paraules.end()){
		v.push_back({it->first, it->second});
		++it;
	}
	sort (v.begin(), v.end(), ordena);
	cout<< v[0].s << " " << v[0].n <<endl;


	for (int i=v.size()-1; i>=0; --i){
		if(i!=0 and v[i].n!=v[i-1].n){
			cout<< v[i].s << " " << v[i].n <<endl;
			i=-1;
		}
		else if (i==0)cout<< v[0].s << " " << v[0].n <<endl;
	}
	

}