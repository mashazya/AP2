#include <iostream>
using namespace std;

struct BinTree{
	int element;
	BinTree* left;
	BinTree* right;

	~BinTree(){
		delete left;
		delete right;
	}
}; 
using Tree = BinTree*;

void insert_v(Tree& T,int v){
	if (T == nullptr){
		T = new BinTree{v, nullptr, nullptr};
	}
	else if (v < T-> element) insert_v(T->left, v);
	else if (v > T-> element) insert_v(T->right, v);
}

void preorder(Tree& T){
	if (T != nullptr){
		cout << T->element << endl;
		preorder(T->left);
		preorder(T->right);

	}
}

int main(){

	Tree T = nullptr;
	int v;
	while (cin >> v){
		insert_v(T,v);
	}
	preorder(T);
	delete T;
}

