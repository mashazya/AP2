#include <algorithm>
#include <cmath>
#include <iostream>
#include <vector>

using namespace std;

// Structure to represent a point (x, y coordinates)
struct Point {
    double x, y;
};

// Returns the distance between two points
double Distance(const Point& p1, const Point& p2) {
    double dx = p1.x-p2.x;
    double dy = p1.y-p2.y;
    return sqrt(dx*dx + dy*dy);
}

// Compares two points by the x coordinate (smallest first)
// In case of a tie, it compares by the y coordinate.
bool sortX(const Point& p1, const Point& p2) {
    if (p1.x != p2.x) return p1.x < p2.x;
    return p1.y < p2.y; 
}

// Compares two points by the y coordinate (smallest first).
// In case of a tie, it compares by the x coordinate.
bool sortY(const Point& p1, const Point& p2) {
    if (p1.y != p2.y) return p1.y < p2.y;
    return p1.x < p2.x; 
}

// Pre: X is a vector of points sorted by the x coordinate
//      Y is a vector of points sorted by the y coordinate
//      Y contains the same points in X[i..j]
//      If two points have the same x coordinate, they are both inside or outside X[i..j] 
// Returns the smallest distance of a pair of points in X[i..j].
// If i == j, it returns infinity.
double ClosestPoints(const vector<Point>& X, int i, int j, const vector<Point>& Y) {
    

    
    // Basic case: all the points have the same x coordinate.
    // We just need to compare the sorted y's and return the min distance.
    // In case of having only one point, it returns infinity.
    if (X[i].x == X[j].x) {
        double d = numeric_limits<double>::infinity();
        int size=Y.size();
        for (int k = 0; k < size-1; ++k) {
            d = min(d, Y[k+1].y - Y[k].y);
        }

        return d;
    }


    // Divide and conquer: split X[i..j] into two segments.
    // Make sure that all the points with the same x coordinate
    // are consistently split (all inside or all outside)
    int mid = (i+j)/2;
    double midx = X[mid].x;
    // All those with the same x are also included
    

    if (X[mid].x==X[j].x){
        
        while (mid > i and X[mid-1].x == midx) --mid;
    }
    else while (mid < j and X[mid+1].x == midx) ++mid;
    // Create two vectors from Y (left and right) sorted by the y coordinates
    vector<Point> Yleft, Yright;
    for (const Point& p: Y) {
        if (p.x <= midx) Yleft.push_back(p);
        else Yright.push_back(p);
    }

    double d;
    // Find the smallest distance at each side
    d = min(ClosestPoints(X, i, mid, Yleft), ClosestPoints(X, mid+1, j, Yright));
    // Calculate the limits of the central strip
    
    
    double xmin = midx - d;
    double xmax = midx + d;

    // Calculate the points in the central strip sorted by the y coordinate
    vector<Point> Ymid;
    for (const Point& p: Y) {
        if (p.x >= xmin and p.x <= xmax) Ymid.push_back(p);
    }

    // Find the smallest distance (visit points in order)
    for (int k = 0; k < Ymid.size(); ++k) {
        for (int q = k+1; q < Ymid.size(); ++q) {
            // Check when there is no need to look for more points
            if (Ymid[q].y - Ymid[k].y >= d) break; // Too far
            d = min(d, Distance(Ymid[q], Ymid[k]));
        }
    }

    return d;
}


// Main program: reads a list of points (pairs of (x,y) coordinates)
// and writes the shortest distance between two points.
int main() {
    cout.setf(ios::fixed);
    cout.precision(5);
    vector<Point> X;
    double x, y;
    while (cin >> x >> y) X.push_back({x, y});
    vector<Point> Y = X;
    // X and Y are identical copies of the vector of points.
    // We now sort them by the x and y coordinates.
    sort(X.begin(), X.end(), sortX);
    sort(Y.begin(), Y.end(), sortY);

    cout << ClosestPoints(X, 0, X.size()-1, Y) << endl;
}