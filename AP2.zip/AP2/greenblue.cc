#include <iostream>
#include <vector>
using namespace std;



struct BinTree{
	char color;
	BinTree* left;
	BinTree* right;

	~BinTree(){
		delete left;
		delete right;
	}
};

using Tree = BinTree*;

Tree read_tree (){
	Tree T;
	char c;
	if(cin >> c and c != '-'){
		Tree left = read_tree();
		Tree right = read_tree();
		T = new BinTree{c, left, right};
		return T;
	}
	return nullptr;

}

int blue_height(Tree T, bool& g_b){

	if (T == nullptr) return 0;
	// comprovo que els veins del verd no siguin verds
	if (T->color == 'G') {
	    if ((T->left != nullptr and T->left->color == 'G') or (T->right != nullptr and T->right->color == 'G')) {
			g_b = false;
			return -1;
	    }
	}
	int left_h = blue_height(T->left, g_b);
	int right_h = blue_height(T->right, g_b);
	if (left_h != right_h){
		g_b = false;
		return -1;
	}
	else{
		if (T->color == 'B') return right_h + 1; // si estem en un blau ha de sumar un
		return right_h;
	}

}

bool green_blue(Tree T, int& height) {
	bool g_b = true;//es un arbre green blue
	height = blue_height(T, g_b);
	if (g_b) return true;
	return false;
}

int main(){
	int n;
	cin >> n;
	for (int i = 0; i<n; ++i){
		Tree T = read_tree();
		int height = 0;
		if (green_blue(T, height)) cout << height<<endl; 
		else cout << "no"<<endl;
		delete T;
	}
}