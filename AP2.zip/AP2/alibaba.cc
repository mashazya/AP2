#include <iostream>
#include <set>
#include <string>
#include <algorithm>
using namespace std;

int main(){
	int n;
	cin>>n;

	string s;
	long suma = 0;
	set <long> cave;
	set <long> bossa;
	while (cin>> s){
		long k;
		if (s=="leave") {
			cin>>k;
			bossa.insert(k);
			suma=suma+k;
			if (bossa.size()>n){
				auto it = bossa.begin();
				suma=suma-(*it);
				cave.insert(*it);
				bossa.erase(*it);
			}
		}
		else {
			cin>>k;
			cave.erase(k);
			bossa.erase(k);
			if (bossa.size()<n) {
				suma=suma-k;
				if(cave.size()!=0){
					auto it = cave.end();
					--it;
					bossa.insert(*it);
					suma=suma+(*it);
					cave.erase(*it);
				}
			}
		}
		cout << suma<<endl;
	}

}