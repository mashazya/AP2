#include <iostream>
#include <vector>
#include <queue>
using namespace std;
using Map = vector<vector<char>>;
using Matrix = vector<vector<bool>>;
using Dist = vector<vector<int>>;

struct Point{
	int x,y;
};

vector <Point> veins (const Map& M, const Point& V){
	vector <Point> v;
	if (V.x+1 < M.size()) v.push_back({V.x+1,V.y});
	if (V.x-1 >=0) v.push_back({V.x-1,V.y});
	if (V.y+1 < M[0].size()) v.push_back({V.x,V.y+1});
	if (V.y-1 >=0) v.push_back({V.x, V.y-1});

	return v;
}

void es_pot_anar (const Map& M, const Point& inici){
	Matrix visitat (M.size(), vector<bool> (M[0].size(),false));
	Dist distance (M.size(), vector<int> (M[0].size(),0));

	queue <Point> q;
	q.push(inici);
	visitat [inici.x][inici.y]=true;
	while (!q.empty()){
		Point v = q.front();
		q.pop();
		if (M[v.x][v.y]=='t') {
			cout<< "minimum distance: " << distance[v.x][v.y]<<endl;
			return;
		}
		for (Point i : veins(M,v)){
			if (!visitat[i.x][i.y] and M[i.x][i.y] != 'X'){
				visitat[i.x][i.y]=true;
				distance[i.x][i.y]=distance[v.x][v.y]+1;
				q.push(i);
			}

		}
	}
	cout<< "no treasure can be reached" <<endl;
}

int main(){
	int n,m;
	cin >> n >> m;
	Map M (n, vector<char>(m));
	for (int i = 0; i<n; ++i){
		for (int j = 0; j<m; ++j){
			cin >> M[i][j];
		}
	}
	Point inici;
	int x,y;
	cin >> inici.x >> inici.y;
	--inici.x; --inici.y;

	es_pot_anar(M,inici);
	
}