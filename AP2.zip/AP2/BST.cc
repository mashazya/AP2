#include <iostream>
using namespace std;

struct BinTree{
	int element;
	BinTree* left;
	BinTree* right;

	~BinTree(){
		delete left;
		delete right;
	}
}; 
using Tree = BinTree*;

Tree read_tree (){
	int v;
	cin >> v;
	if (v == -1) return nullptr;
	else{
		Tree left = read_tree();
		Tree right = read_tree();
		
		return new BinTree{v,left,right};
	}
}

bool there_is_element(Tree T, int v){
	if (T!= nullptr and T->element == v) return true;
	else if (T!= nullptr and T->left != nullptr and v < T->element) {
		return there_is_element(T->left, v);
	}

	else if (T!= nullptr and T->right != nullptr and v > T->element) {
		return there_is_element(T->right, v);
	}

	return false;

}

int main(){
	int vertexs;
	cin >> vertexs;
	Tree T = read_tree();
	int v;
	while (cin >> v){
		if (there_is_element(T,v)) cout << v << " 1" <<endl;
		else cout << v << " 0" <<endl;
	}
	delete T;
}

