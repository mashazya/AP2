#include <iostream>
#include <queue>
#include <string>
#include <iomanip>
using namespace std;

int main (){
	char c;
	priority_queue <int> pq;
	int x;
	while (cin>>c){
		if (c=='S'){
			cin>>x;
			pq.push(x);
		}
		if (c=='A'){
			if (not pq.empty()){
				cout<< pq.top()<<endl;
			}
			else cout<< "error!" << endl;
		}
		if (c=='R') {
			if (not pq.empty()) pq.pop();
			else cout<< "error!" << endl;
		}
		if (c=='I'){
			if (not pq.empty()){
				cin>>x;
				int max = pq.top(); pq.pop();
				max=max+x;
				pq.push(max);
			}
			else cout<< "error!" << endl;
		}
		if (c=='D'){
			if (not pq.empty()){
				cin>>x;
				int min = pq.top(); pq.pop();
				min=min-x;
				pq.push(min);
			}
			else cout<< "error!" << endl;
		}

		
	}
}