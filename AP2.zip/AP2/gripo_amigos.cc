#include <iostream>
#include <vector>
#include <queue>
#include <string>
#include <algorithm>
#include <set>
using namespace std;
using Graph = vector<set<int>>;

bool find_names (Graph& G, int& set, vector<string> names){
	
	for (int j = 0; j<names.size(); ++j){
		for (int i = 0; i<G.size(); ++i){
			if (G[i].find(names[j]) != end()){
				set = i;
				return true;
			}
		}
	}
	return false;
}

void opera_F(Graph& G){
	int n;
	string name;
	cin >> n;
	vector<string> names;
	for (int i = 0; i<n; ++i){
		cin >> name;
		names.push_back(name);
		int set = 0;
		if (G.size() == 0 or not find_names(G,set, names)){
			set<int> amigo = {name};
			G.push_back(amigo);
		}
		else{
			G[set].insert(name);
		}
	}
}
void opera_C(){
	string name;
	cin >> name;

	cout << name << ": ";
}

int main(){
	char c;
	while (cin >> c){
		Graph G;
		if (c == 'F'){
			opera_F(G);
		}
		else if (c == 'Q'){
			opera_C();
		}
	}
}