#include <iostream>
#include <stack>
#include <cctype>
#include <string>
using namespace std;

bool correcta (string c){
	stack <char> pila;
	for (int i=0; i<c.size(); ++i){
			if (pila.empty()) pila.push(c[i]);
			else if (pila.top()=='(' and c[i]==')') pila.pop();
			else if (pila.top()=='[' and c[i]==']') pila.pop();
			else pila.push(c[i]);
		}
	return pila.empty();

}

int main(){
	string c;
	while(cin>>c){
		if (correcta(c)){
			cout<< c<< " is correct"<<endl;
		}
		else cout << c << " is incorrect" <<endl;
	}

}