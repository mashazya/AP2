#include <iostream>
#include <queue>
#include <string>
#include <iomanip>
using namespace std;



int main(){
	cout.setf(ios::fixed);
	cout.precision(4);

	string s;
	int n;
	priority_queue <int> pq;
	priority_queue <int, vector<int>, greater<int>> pqm;
	double suma=0;
	while (cin>>s){
		if (s== "number"){
			cin >>n;
			suma=suma+n;
			pq.push(n);
			pqm.push(n);
			cout<< "minimum: " << pqm.top() << ", ";
			cout<< "maximum: " << pq.top() << ", ";
			cout<< "average: " << suma/pqm.size() << endl;

		}
		else if (s=="delete"){
			if (not pqm.empty()){
				suma=suma-pqm.top();
				pqm.pop();
				if (not pqm.empty()){
					cout<< "minimum: " << pqm.top() << ", ";
					cout<< "maximum: " << pq.top() << ", ";
					cout<< "average: " << suma/pqm.size() << endl;
				}


			}
			if (pqm.empty()) {
				cout<< "no elements"<<endl;
				while (not pq.empty()){
					pq.pop();
				}
			}
		}


	}
	
}



