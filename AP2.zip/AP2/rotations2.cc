#include <iostream>
#include <vector>
#include <string>
#include <algorithm>
using namespace std;


int find_min (const vector<int>& v, int left, int right){

    if(left<right){
        int mid = (left+right)/2;
        if (v[mid]<v[right]){
            return find_min(v,left,mid);
        }
        else if (v[mid]>v[right]){
            return find_min(v,mid+1,right);
        }

    }
    return left;
}

int number_of_rotations (const vector<int>& v){
    int left = 0;
    int right = v.size()-1;
    if (v[left]<v[right]) return 0;
    return find_min(v,left,right);
}


int main() {
    int n;
    while (cin >> n) {
        vector<int> v(n);
        for (int i = 0; i < n; ++i) cin >> v[i];
        cout
            << number_of_rotations(v)
            << endl
        ;
    }
}