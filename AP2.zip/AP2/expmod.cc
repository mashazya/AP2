#include <iostream>
#include <algorithm>
using namespace std;

int exponent (int n, int k, int m){
	if (k==0) return 1;
	else if (k%2==0){
		int x= exponent(n%m, k/2, m);
		x=x*x;
		return x%m;
	}
	else{
		int x = exponent(n, (k-1), m);
		return (n*x)%m;
	}
}

void resultat (int n, int k, int m){
	cout<< exponent(n,k,m)<<endl;
}

int main(){
	int n,k,m;
	while(cin>> n>>k>>m){
		resultat(n,k,m);
	}
}