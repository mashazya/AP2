#include <iostream>
#include <map>
#include <string>
#include <set>
#include <vector>
using namespace std;

int main(){
	string a = "345";
	int b = int(a);
	
}