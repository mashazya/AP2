#include <iostream>
#include <vector>
#include <set>
#include <stack>
using namespace std;
using Graph = vector<vector<int>>;

Graph reverse (const Graph& G, int vertexs){
	Graph Gr(vertexs);
	for (int v=0; v < vertexs; ++v){
		for (int u : G[v]) Gr[u].push_back(v);
	}

	return Gr;
}

void explore(const Graph& Gr, int v, vector<bool>& visited, stack<int> & postvisit){
	visited[v] = true;
	for (int u : Gr[v]){
		if (!visited[u]) explore (Gr, u, visited,postvisit);
	}
	//cout << "posvisit " << v << endl;
	postvisit.push(v);
}


void DFS (const Graph& Gr, int vertexs, stack<int>& postvisit){
	vector<bool> visited (vertexs,false);
	for (int v=0; v<vertexs; ++v){
		if (!visited[v]){
			explore(Gr,v,visited,postvisit);
		}
	}
}

void conncomp (const Graph& G, int v, vector<int>& ccnum, int&cc){
	ccnum[v]=cc;
	for (int u : G[v]){
		if (ccnum[u]==0) conncomp (G, u, ccnum, cc);
	}
}

void calcula_ccnum (Graph& G, vector<int>& ccnum, int vertexs){
	Graph Gr = reverse(G, vertexs);
	stack <int> postvisit;
	DFS (Gr,vertexs, postvisit);
	/*cout << "stack:" <<endl;
	stack<int> copia = postvisit;
	while (!copia.empty()){
		cout<< copia.top()<<endl; copia.pop();

	}*/
	int cc = 1;
	while (!postvisit.empty()){
		int v = postvisit.top(); postvisit.pop();
		if (ccnum[v]==0){
			conncomp(G,v,ccnum,cc);
			++cc;
		}
	}

}

int SCC (Graph& G, int vertexs){
	set <int> S;
	vector <int> ccnum (vertexs,0);

	calcula_ccnum(G,ccnum,vertexs);

	for (int i = 0; i<ccnum.size(); ++i){
		S.insert(ccnum[i]);
	}

	return S.size();
}

int main(){
	int n;
	cin >> n;
	for (int i = 0; i<n; ++i){
		int vertexs, arestes;
		cin >> vertexs >> arestes;
		Graph G(vertexs);

		int u,v;
		for (int j = 0; j<arestes; ++j){
			cin >> u >> v;
			G[u].push_back(v);
		}

		cout << "Graph #" << i+1 << " has " << SCC(G, vertexs) << " strongly connected component(s)." << endl;
	}
}