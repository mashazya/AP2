#include <iostream>
#include <map>
using namespace std;

void evalua_rifa (int n, const map <int,int> & rifa, const map  <int,int> & acabaments, int& max_repe, int& maxr, int& max_acaba, int& maxa){
	auto it = rifa.find(n);
	if (it->second >= max_repe) {
		if (it->second==max_repe and (it->first <= maxr or rifa.size()==1)){
			max_repe = it->second;
			maxr = it->first;
		}
		else if (it->second!=max_repe) {
			max_repe = it->second;
			maxr = it->first;
		}
		
	}

	it = acabaments.find(n%100); 
	if (it->second >= max_acaba) {
		if (it->second==max_acaba and (it->first <= maxa or acabaments.size()==1)){
			max_acaba = it->second;
			maxa = it->first;
		}
		else if (it->second!=max_acaba) {
			max_acaba= it->second;
			maxa = it->first;
		}
		
	}

	
}

int main(){
	int n;
	map <int, int> rifa;// num, aparicions
	map <int, int> acabaments;
	map <int, int> buit;
	int max_repe=0;
	int maxr = 0;
	int max_acaba=0;
	int maxa = 0;

	while (cin >> n){
		if (n != -1) {
			++rifa[n];
			++acabaments[n%100];
			evalua_rifa(n, rifa, acabaments, max_repe, maxr, max_acaba, maxa);
			cout << maxr << " " << max_repe << " ";
			if ( maxa < 10) cout << "0";
			cout<< maxa << " " << max_acaba<<endl;

		}
	
		else {
			cout << endl;
			for (auto it = rifa.begin(); it!= rifa.end(); ++it){
				cout << it->first << " " << it->second << endl;
			}
			cout << "----------" << endl;
			rifa = buit;
			acabaments = buit;
			max_repe=0;
			maxr = 0;
			max_acaba=0;
			maxa = 0;
		}
	}
}