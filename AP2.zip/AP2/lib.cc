#include <iostream>
#include <sstream>
#include <stack>
#include <string>
#include <vector>
using namespace std;

void escriu (vector <stack<string>>& v){
	for (int i = 0 ; i<v.size(); ++i){
		int num = i+1;
		cout << "Stack " << num << ":";
		stack <string> copia; 
		while (!v[i].empty()){
			copia.push(v[i].top());
			v[i].pop();
		}
		while (!copia.empty()){
			cout << " " << copia.top();
			copia.pop();
		}
		cout << endl;
	}
}

int main(){
	int n;
	cin >> n;
	vector <stack <string>> lib;
	string s;
	getline(cin, s);
    for (int i = 0; i<n; ++i){
    	string book, t;
   		stack <string> type;
    	getline(cin, t);
    	istringstream iss(t);
    	while (iss >> book){
    		type.push(book);
    	}
    	lib.push_back(type);

	}

    string operacio;
    while (cin >> operacio){
    	if (operacio == "LOAN"){
    		int posicio;
    		cin >> posicio;
    		--posicio;
    		if (posicio >= 0 and posicio < lib.size()){
    			if (!lib[posicio].empty()) lib[posicio].pop();
    		}
    	}
    	else {
    		string name;
    		int posicio;
    		cin >> name >> posicio;
    		--posicio;
    		if (posicio >= 0 and posicio < lib.size()){
    			lib[posicio].push(name);
    		}
    	}
    }
    escriu(lib);
}