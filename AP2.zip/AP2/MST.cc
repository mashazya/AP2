#include <iostream>
#include <vector>
#include <queue>
using namespace std;

struct Aresta{
	int dest;
	int weight;
};

bool operator < (const Aresta& a, const Aresta& b){
	return a.weight > b.weight;
}

using Graph = vector<vector<Aresta>>;

void prim (Graph& G, vector <int>& cost, int vertexs){
	vector <bool> visited(vertexs+1, false);
	visited[1]=true;
	priority_queue <Aresta> Q;
	for (Aresta i : G[1]){
		Q.push(i);
	}

	int n = 1;
	
	while (n < vertexs){
		int v = Q.top().dest;
		int costv = Q.top().weight;
		Q.pop();
		if (!visited[v]){
			++n;
			visited[v]=true;
			cost[v]=costv;
			for (Aresta j : G[v]){
				if (!visited[j.dest]) Q.push(j);
			}
		}
	}

}

int MST (Graph& G, int vertexs){
	vector <int> cost(vertexs+1,0); //conte cost de la aresta pare
	cost[1]=0;
	int sum = 0;
	prim (G,cost,vertexs);
	for (int i = 1; i< cost.size(); ++i){
		sum += cost[i];
	}
	return sum;
}

int main(){
	int vertexs, arestes;
	while (cin >> vertexs >> arestes){
		Graph G(vertexs+1);
		int u, v, w;
		for (int i = 0; i < arestes; ++i){
			cin >> u >> v >> w;
			G[u].push_back({v,w});
			G[v].push_back({u,w});
		}
		cout << MST(G,vertexs) << endl;
	}
}