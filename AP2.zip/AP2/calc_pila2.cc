#include <iostream>
#include <sstream>
#include <stack>
#include <cctype>
#include <string>
using namespace std;

int convierte_en_num (const string& c){
	int k=1;
	int res=0;
	for (int i = c.size()-1; i>=0; --i){

		res=res+((c[i]-'0')*k);
		k=k*10;
	}

	return res;
}


int main(){
	stack <int> pila;
	string s;

	while(getline(cin,s)){
		istringstream iss(s);
		string c;
		while (iss >> c){
			if (isdigit(c[0])) {
				if (c.size()>1) pila.push(stoi(c));
				else pila.push(c[0] -'0');
			}
			else{
				int x = pila.top();
				pila.pop();


				int y =  pila.top();
				pila.pop();


				if (c[0]=='+') pila.push(x+y);
				if (c[0]=='-') pila.push(y-x);
				if (c[0]=='*') pila.push(x*y);
			}

		}
		cout<< pila.top() << endl;
		pila.pop();
	}

}



