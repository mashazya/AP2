#include <iostream>
#include <map>
#include <string>
using namespace std;

int main(){
	map <string, int> c;
	string action;
	while(cin>>action){
		string w;
		if (action=="store"){
			cin>> w;
			if (c.count(w)==0) c.insert({w, 1});
			else ++c[w];
		}
		else if(action=="delete"){
			cin>>w;
			auto it = c.find(w);
			if (it->second==1) c.erase(w);
			else if (it->second>1 and it!=c.end()) --c[w];
		}
		else if (action=="minimum?"){
			if (c.size()>0){
				auto it = c.begin();
				cout<<"minimum: "<< it->first <<", "<< it->second<< " time(s)"<<endl;
			}
			else cout<< "indefinite minimum"<<endl;
		}
		else if (action=="maximum?"){
			if (c.size()>0){
				auto it = c.end();
				--it;
				cout<<"maximum: "<< it->first <<", "<< it->second<< " time(s)"<<endl;
			}
			else cout<< "indefinite maximum"<<endl;
		}
	}
}