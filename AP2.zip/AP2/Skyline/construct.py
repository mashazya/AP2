class Skyline:
	_Point=namedtuple('Point'['x','h'])
	det __init__(self, sky=None):
	"""....."""
	if sky == None:
		self.points=[]
	elif isinstance(sky,tuple):
		self._create_from_tuple(sky)
	elif isinstance(sky,list):
		self._create_from_list(sky)
	elif isinstance(sky,str):
		self._create_from_file(sky)
	else:
		raise TypeError("Incorrect parameter")



