from skyline_correccio import Skyline as Sky
import time

a= Sky ([(1,7,3),(3,2,5),(4,5,8)])
a.view()
'''start_time = time.time()
print("The area of the big skyline is", big.area(), "and the tallest height is", big.height())
print("--- %s seconds ---" % (time.time() - start_time))'''
