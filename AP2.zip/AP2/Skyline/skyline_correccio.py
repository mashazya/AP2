import collections
from matplotlib import pylab
import matplotlib.pyplot
from matplotlib.ticker import MaxNLocator

class Skyline:
    
    def __init__(self, sky=None):

        if sky == None:
            # Creates an empty list of buildings
            self._buildings = []
        elif isinstance(sky, tuple):
            # Creates a list of one building
            self._create_from_tuple(sky)
        elif isinstance(sky, list):
            # Creates a list of buildings from a list
            self._create_from_list(sky)
        elif isinstance(sky, str):
            # Creates a list of buildings from a file 
            self._create_from_file(sky)
        else:
            raise TypeError("Incorrect parameter to define a skyline")


    def _create_from_tuple(self, sky):
        if (sky[0] < 0):
            raise TypeError("Incorrect parameter to define a skyline, xmin must be at least 0")
        elif (sky[1] <= 0):
            raise TypeError("Incorrect parameter to define a skyline, h must be  bigger than 0")
        elif (sky[2] <= sky[0]):
            raise TypeError("Incorrect parameter to define a skyline, xmax must be bigger than xmin")
        elif not (isinstance(sky[0], int) and isinstance(sky[1], int) and isinstance(sky[2], int)):
                raise TypeError("Incorrect parameter to define a skyline, tuple values are not integers")
        self._buildings = [sky]
        self._area = (sky[2] - sky[0]) * sky[1]
        self._height = sky[1]


    def _create_from_list(self, sky):
        """Creates a list of buildings from a list, in order to increase the efficiency it sorts that list"""
        self._buildings = []
        sky.sort()
        for i in range(len(sky)):
            if (sky[i][0] < 0):
                raise TypeError("Incorrect parameter to define a skyline, xmin must be at least 0")
            elif (sky[i][1] <= 0):
                raise TypeError("Incorrect parameter to define a skyline, h must be  bigger than 0")
            elif (sky[i][2] <= sky[i][0]):
                raise TypeError("Incorrect parameter to define a skyline, xmax must be bigger than xmin")
            elif not (isinstance(sky[i][0], int) and isinstance(sky[i][1], int) and isinstance(sky[i][2], int)):
                    raise TypeError("Incorrect parameter to define a skyline, tuple values are not integers")
            self._add_building(sky[i])


    def _create_from_file(self, sky):
        file = open(sky, 'r')
        vector = []
        for line in file.readlines():
            each_line = line.strip()
            n = each_line.split()
            # Checks if skyline is defined with correct parameters
            if (int(n[0]) < 0):
                raise TypeError("Incorrect parameter to define a skyline, xmin must be at least 0")
            elif (int(n[0]) <= 0):
                raise TypeError("Incorrect parameter to define a skyline, h must be  bigger than 0")
            elif (int(n[2]) <= int(n[0])):
                raise TypeError("Incorrect parameter to define a skyline, xmax must be bigger than xmin")

            building = (int(n[0]), int(n[1]), int(n[2]))
            vector.append(building)
        file.close()
        self._create_from_list(vector)


    def _add_building(self, new):
        """Adds a new building to the list if it is not covered by another one, returns nothing"""
        n = len(self._buildings)
        if n == 0:
            self._buildings.append(new)
        else:
            # Elements of the last building in the skyline
            xmin = self._buildings[n-1][0]
            height = self._buildings[n-1][1]
            xmax = self._buildings[n-1][2]
            # Comparison:
            if xmin <= new[0]:  # last building starts before the new one or both start at the same x
                if xmax < new[0]: self._buildings.append(new)
                elif xmax == new[0]:
                    if height == new[1]:
                        self._buildings.pop()
                        self._buildings.append((xmin, height, new[2]))
                    else: self._buildings.append(new)
                elif new[0] < xmax:  # new building[0] < xmax
                    if height == new[1]:  # new building is covered by the last one
                        if xmax <= new[2]:  # new building is not totally covered, else we do nothing
                            self._buildings.pop()
                            self._buildings.append((xmin, height, new[2]))
                    elif new[1] < height:  # part of a shorter new building is coverd by the previous
                        if xmax < new[2]:  # new building is not completely covered
                            self._buildings.append((xmax, new[1], new[2]))
                    elif height < new[1]:  # new buliding is covered by a shorter building
                        if xmax < new[2]:  # new building's base partially covered
                            self._buildings.pop()
                            if xmin < new[0]: self._buildings.append((xmin, height, new[0]))
                            self._buildings.append(new)
                        elif new[2] < xmax:  # new building's base is totally covered
                            self._buildings.pop()
                            if xmin < new[0]: self._buildings.append((xmin, height, new[0]))
                            self._buildings.append(new)
                            self._buildings.append((new[2], height, xmax))
                        elif new[2] == xmax:
                            self._buildings.pop()
                            if xmin < new[0]: self._buildings.append((xmin, height, new[0]))
                            self._buildings.append(new)

            elif new[0] < xmin:  # new building starts before the last one
                self._deleted = []  # vector with the deleted buildings, the ones with xmin bigger than new[0]
                i = n-1
                while i >= 0 and new[0] <= self._buildings[i][0]:
                    self._deleted.append(self._buildings[i])
                    self._buildings.pop()
                    i -= 1
                self._add_building(new)
                j = len(self._deleted)-1
                while j >= 0:
                    self._add_building(self._deleted[j])
                    j -= 1


    def area(self):
        """Calculates the area of the skyline with O(n) complexity if the skyline has no attribute _area, else takes constant time"""
        if not hasattr(self, '_area'):
            area = 0
            for i in range(len(self._buildings)):
                building = self._buildings[i]
                base = building[2] - building[0]
                h = building[1]
                area += base * h
            self._area = area
        return self._area

    
    def height(self, x=None):
        """Calculates the maximum hight of the skyline in case an x is not given, else returns the height on a fixed x value"""
        if x == None:
            if not hasattr(self, '_height'):
                self._height = self._buildings[0][1]
                for building in self._buildings:
                    if building[1] > self._height: 
                        self._height = building[1]
            return self._height
        else:
            if x == self._buildings[0][0]: return self._buildings[0][1] 
            for i in range(len(self._buildings)):
                building = self._buildings[i]
                if building[0] < x < building[2]: return building[1]
                if x == building[0]:
                    prev = self._buildings[i-1]
                    if building[0] != prev[2]: return building[1]
                    return max(prev[1], building[1])
            if x == building[2]: return building[1]
            return 0


    def _contained(self, little, big):
        """Returns True if little is contained in big"""
        if big[0] <= little[0] and little[1] <= big[1] and little[2] <= big[2]: return True
        return False


    def __add__(self, other):
        """Returns a new skyline which represents the union of 2 skylines using an algorithm similar to the last phase of merge sort"""
        sum = Skyline()
        sum._buildings = self._buildings
        if hasattr(self, '_height') and hasattr(other, '_height'):
            sum._height = max(self._height, other._height)
        i = 0  # First building of self
        j = 0  # First building of other
        while i < len(sum._buildings) and j < len(other._buildings):
            BS = sum._buildings[i]
            BO = other._buildings[j]
            if BS[2] <= BO[0]:
                i += 1
            else:
                if self._contained(BS, BO):
                    sum._buildings.remove(BS)
                    sum._buildings.insert(i, BO)
                    j += 1
                elif self._contained(BO, BS):
                    j += 1
                elif BO[2] <= BS[0]:  # Other building is before self building and does not cover it
                    sum._buildings.insert(i, BO)
                    j += 1
                else:  # Buildings cover each other partially 
                    if BS[0] <= BO[0]:  # Self building is the one at the left
                        if BS[1] > BO[1]:  # Self building is taller or equal than other
                            sum._buildings.insert(i+1, (BS[2], BO[1], BO[2]))
                            i += 1
                        elif BS[1] == BO[1]:
                            sum._buildings.remove(BS)
                            sum._buildings.insert(i, (BS[0], BS[1], BO[2]))
                            i += 1
                        else:  # Self building is shorter
                            sum._buildings.remove(BS)
                            if BS[0] == BO[0]:
                                sum._buildings.insert(i, BO)
                                sum._buildings.insert(i+1, (BO[2], BS[1], BS[2]))
                                i += 1
                            else:
                                sum._buildings.insert(i, (BS[0], BS[1], BO[0]))
                                sum._buildings.insert(i+1, BO)
                                sum._buildings.insert(i+2, (BO[2], BS[1], BS[2]))
                                i += 2
        # If the loop arrives to the last building of sum we append the rest of other buildings
        while j < len(other._buildings):
            BO = other._buildings[j]
            sum._buildings.append(BO)
            j += 1
        return sum


    def __iadd__(self, other):
        """Changes the value of the skyline to the sum of it with another one"""
        sum = self.__add__(other)
        self = sum
        if hasattr(self, '_area'): delattr(self, '_area')
        return self  # it returns the skyline that has been modified

    def __mul__(self, other):
        """Returns the intersection of two skylines in a new one without modifying any of those two"""
        intersection = Skyline()
        i = 0
        j = 0
        while i < len(self._buildings) and j < len(other._buildings):
            BS = self._buildings[i]
            BO = other._buildings[j]
            if len(intersection._buildings) > 0: building = intersection._buildings[len(intersection._buildings)-1]
            if BS[2] < BO[0]:
                i += 1
            elif BO[2] < BS[0]:
                j += 1
            elif self._contained(BS, BO):
                intersection._buildings.append(BS)
                i += 1
            elif self._contained(BO, BS):
                intersection._buildings.append(BO)
                j += 1
            else:
                h = min(BS[1], BO[1])
                xmin = max(BS[0], BO[0])
                xmax = min(BS[2], BO[2])
                tuple = (xmin, h, xmax)
                if len(intersection._buildings) > 0 and tuple[1] == building[1] and tuple[0] <= building[2]:
                    intersection._buildings.pop()
                    tuple = (building[0], h, xmax)
                intersection._buildings.append(tuple)
                if xmax == BS[2]: i += 1
                else: j += 1
        return intersection


    def __imul__(self, other):
        """Changes the value of a skyline to the intersection of it with another given one"""
        intersection = self.__mul__(other)
        self = intersection
        if hasattr(self, '_area'): delattr(self, '_area')
        if hasattr(self, '_height'): delattr(self, '_height')
        return self  # it returns the skyline that has been modified


    def find_slot(self, width=None):
        """Returns the beginning of an interval with a given width without buildings, if no width is given it returns the largest interval without buildings"""
        if width == None:
            x = 0
            width = self._buildings[0][0]
            for i in range(len(self._buildings)-1):
                building = self._buildings[i]
                next = self._buildings[i+1]
                if next[0] - building[2] > width:
                    width = next[0] - building[2]
                    x = building[2]
            return (x, width)
        else:
            if self._buildings[0][0] >= width:
                return 0
            for i in range(len(self._buildings)-1):
                building = self._buildings[i]
                next = self._buildings[i+1]
                if next[0] - building[2] >= width:
                    return building[2]
            return next[2]

        


    def select(self, xmin, xmax):
        """Crops the skyline to a given minimum and maximum value of the x component"""
        if hasattr(self, '_area'): delattr(self, '_area')
        if hasattr(self, '_height'): delattr(self, '_height')
        new_buildings = []
        i = 0
        while i < len(self._buildings)-1 and self._buildings[i][0] < xmax:
            building = self._buildings[i]
            if xmin <= building[0] and building[2] <= xmax:
                new_buildings.append(building)
            elif building[0] < xmin < building[2]:
                new_buildings.append((xmin, building[1], building[2]))
            elif building[0] < xmax < building[2]:
                new_buildings.append((building[0], building[1], xmax))
            i += 1
        self._buildings = new_buildings
        return self  # it returns the skyline that has been modified


    def cut_top(self, height):
        """Reduces the skyline hight to a given one, only modifying those buildings that are higher than the wished height"""
        self._height = height
        if hasattr(self, '_area'): delattr(self, '_area')
        for i in range(len(self._buildings)):
            building = self._buildings[i]
            if building[1] > height:
                self._buildings.remove(building)
                self._buildings.insert(i, (building[0], height, building[2]))
        return self  # it returns the skyline that has been modified


    def bbox(self):
        """Returns a skyline of one only building that has the minimum components to contain a determined other skyline, without modifying it"""
        assert(len(self._buildings) > 0)
        xmin = self._buildings[0][0]
        h = self.height()
        xmax = self._buildings[len(self._buildings)-1][2]
        box = Skyline((xmin, h, xmax))
        return box


    def span(self):
        """Returns the minimum and maximum values of the x coordinate of the hole skyline"""
        if len(self._buildings) == 0: return (0, 0)
        xmin = self._buildings[0][0]
        xmax = self._buildings[len(self._buildings)-1][2]
        return (xmin, xmax)


    def view(self):
        """Plots a skyline with rectangular buildings"""
        ax = pylab.figure().gca()
        ax.xaxis.set_major_locator(MaxNLocator(integer=True))
        ax.yaxis.set_major_locator(MaxNLocator(integer=True))
        for i in range(len(self._buildings)):
            b = self._buildings[i]
            width = b[2] - b[0]
            bar = pylab.bar(b[0], b[1], width, align='edge', color='red')
       pylab.show()  

    def save(self, name):
        """Saves a skyline into a file with its wanted name"""
        f = open(name, 'w')
        for i in range(len(self._buildings)):
            building = self._buildings[i]
            f.write(str(building[0]) + ' ' + str(building[1]) + ' ' + str(building[2]) + '\n')
        f.close()


    def __repr__(self):
        """Represents a skyline returning a sorted list of buildings"""
        return "Skyline: buildings = " + str(self._buildings)


    def __str__(self):
        """Prints the list of buildings of the skyline"""
        return "Skyline: buildings = " + str(self._buildings)

